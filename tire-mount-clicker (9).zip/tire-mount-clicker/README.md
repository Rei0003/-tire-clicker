# Tire Clicker

A Cookie Clicker–style idle game: click to mount tires, hire crew and buy
equipment to auto-mount tires per second, and complete cars one after
another. Includes account registration, login, and server-side save/load
of progress.

**Architecture:** almost everything is plain HTML, CSS, and JavaScript.
PHP is only used as a thin JSON API for accounts and saving — five small
files under `api/`, nothing else. There's no server-rendered HTML at all;
`index.html` is a static file that both screens (login/register and the
game) live in, and `assets/app.js` drives all of the UI and game logic.

## Requirements

- PHP 7.4+ (PHP 8 recommended) with the **`pdo_sqlite`** extension
  enabled.
- No MySQL/database server needed — it uses a local SQLite file that is
  created automatically on first run.

### "could not find driver" error

If registering or logging in fails with a PDOException about a missing
driver, your PHP install has the SQLite extension disabled. Fix:

1. Run `php --ini` to find the loaded `php.ini` path.
2. Open that file and uncomment (remove the leading `;` from) these two
   lines:
   ```
   extension=pdo_sqlite
   extension=sqlite3
   ```
3. Save the file and restart `php -S localhost:8000`.

On Windows/XAMPP installs these lines are usually present but commented
out by default — this is the most common cause of that error.

## Running it locally

From inside the `tire-mount-clicker` folder, run:

```bash
php -S localhost:8000
```

Then open `http://localhost:8000` in your browser.

## Running it on a normal web host (shared hosting, etc.)

1. Upload the entire `tire-mount-clicker` folder to your host (e.g. via
   FTP, or into `public_html`).
2. Make sure the folder is writable by PHP — a `data/` folder will be
   created automatically to hold `game.db` (the SQLite save file). If
   your host is strict about permissions, `chmod 775` the project folder
   once after upload.
3. Visit the folder's URL in your browser.

## How it works

- `index.html` — the entire UI: the login/register screen and the game
  screen, toggled by JavaScript. No PHP is involved in serving this page.
- `assets/style.css` — the visual theme.
- `assets/app.js` — everything interactive: checking whether you're
  logged in, the login/register forms, the click loop, the shop, the
  idle tick, and autosaving. This is most of the project.
- `api/session.php` — tells the frontend whether you're logged in and
  hands it a CSRF token.
- `api/register.php`, `api/login.php`, `api/logout.php` — JSON endpoints
  the JS calls to manage your account and session.
- `api/save.php`, `api/load.php` — JSON endpoints the JS calls to
  autosave progress (every ~6 seconds, after each purchase, and when the
  tab closes) and to load it back on login.
- `includes/db.php` — opens (and auto-creates) the SQLite database and
  its two tables: `users` and `saves`.
- `includes/auth.php` — session/password/CSRF helper functions shared by
  the `api/` endpoints.

## Customizing

- Generators (auto-mounters) and one-time click upgrades are defined as
  plain arrays at the top of `assets/app.js` (`GENERATORS` and
  `CLICK_UPGRADES`) — add, remove, or re-price them there.
- Cost scaling per generator purchase is `COST_GROWTH` (default `1.15`,
  the classic idle-game curve).
- The car in the bay and the tire on the click button both progress
  through 6 stages as you buy the 5 Garage upgrades (`CLICK_UPGRADES`),
  from a plain street sedan/tire up to an F1 car and finally a rally car.
  Each stage is its own inline SVG in `index.html`, tagged
  `data-tire-tier="0"`–`"5"` and `data-car-tier="0"`–`"5"`; `app.js`
  toggles which one is visible based on how many click upgrades you own
  (`refreshVehicleTier()`). Edit, reorder, or add stages there — each
  car SVG needs exactly two `.wheel-slot` circles for the mount
  animation to target.

## Security notes

This is built for a personal/small project, not a public production
deploy. It already does the important basics — hashed passwords,
prepared statements everywhere, CSRF token on every state-changing
request, session-gated save/load — but if you put it on the open
internet you'll want HTTPS and to consider rate-limiting login attempts.
