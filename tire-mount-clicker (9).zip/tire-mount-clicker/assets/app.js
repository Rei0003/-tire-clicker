(function () {
    'use strict';

    // ================= Config =================

    var GENERATORS = [
        { id: 'rookie', name: 'Rookie Mechanic', baseCost: 15, rate: 1 },
        { id: 'wrenchStation', name: 'Impact Wrench Station', baseCost: 100, rate: 5 },
        { id: 'balancer', name: 'Tire Balancer Rig', baseCost: 600, rate: 20 },
        { id: 'secondBay', name: 'Another Bay', baseCost: 4000, rate: 80 },
        { id: 'pitCrew', name: 'Pit Crew Team', baseCost: 20000, rate: 300 },
        { id: 'hydraulicLine', name: 'Hydraulic Lift Line', baseCost: 100000, rate: 1000 },
        { id: 'deliveryFleet', name: 'Delivery Fleet', baseCost: 500000, rate: 4000 },
        { id: 'warehouse', name: 'Regional Warehouse', baseCost: 2500000, rate: 15000 },
        { id: 'franchise', name: 'National Franchise', baseCost: 12000000, rate: 60000 }
    ];

    var CLICK_UPGRADES = [
        { id: 'boots', name: 'Steel-Toe Boots', cost: 50, add: 1 },
        { id: 'pneumatic', name: 'Pneumatic Wrench', cost: 500, add: 4 },
        { id: 'jack', name: 'Hydraulic Jack', cost: 5000, add: 10 },
        { id: 'roboticArm', name: 'Robotic Torque Arm', cost: 50000, add: 50 },
        { id: 'autoBay', name: 'Full Auto Bay', cost: 500000, add: 250 }
    ];

    var TIRE_TIER_NAMES = ['Street Tire', 'Street Wheel', 'Sport Wheel', 'Off-Road Wheel', 'Racing Wheel', 'Rally Wheel'];

    var COST_GROWTH = 1.15;

    // ================= App/auth state =================

    var csrfToken = null;
    var THEME_KEY = 'tire-clicker-theme';

    // ================= Theme =================

    function applyTheme(theme) {
        if (theme === 'light') {
            document.documentElement.setAttribute('data-theme', 'light');
        } else {
            document.documentElement.removeAttribute('data-theme');
        }
    }

    function initTheme() {
        var stored = null;
        try { stored = localStorage.getItem(THEME_KEY); } catch (e) { stored = null; }

        var theme = stored;
        if (!theme) {
            theme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches)
                ? 'light' : 'dark';
        }
        applyTheme(theme);

        var toggles = document.querySelectorAll('.theme-toggle');
        toggles.forEach(function (toggle) {
            toggle.addEventListener('click', function () {
                var current = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
                var next = current === 'light' ? 'dark' : 'light';
                applyTheme(next);
                try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* ignore */ }
            });
        });
    }

    // ================= Game state =================

    var state = {
        tires: 0,
        totalTires: 0,
        generators: {},
        clickUpgrades: [],
        carsCompleted: 0,
        wheelsOnCurrentCar: 0
    };

    function applyServerState(saved) {
        saved = saved || {};
        state.tires = Number(saved.tires) || 0;
        state.totalTires = Number(saved.totalTires) || 0;
        state.generators = (saved.generators && typeof saved.generators === 'object') ? saved.generators : {};
        state.clickUpgrades = Array.isArray(saved.clickUpgrades) ? saved.clickUpgrades : [];
        state.carsCompleted = Number(saved.carsCompleted) || 0;
        state.wheelsOnCurrentCar = Math.max(0, Math.min(2, Number(saved.wheelsOnCurrentCar) || 0));
    }

    function clickPower() {
        var power = 1;
        for (var i = 0; i < CLICK_UPGRADES.length; i++) {
            if (state.clickUpgrades.indexOf(CLICK_UPGRADES[i].id) !== -1) {
                power += CLICK_UPGRADES[i].add;
            }
        }
        return power;
    }

    function tiresPerSecond() {
        var rate = 0;
        for (var i = 0; i < GENERATORS.length; i++) {
            var g = GENERATORS[i];
            var owned = state.generators[g.id] || 0;
            rate += owned * g.rate;
        }
        return rate;
    }

    function generatorCost(gen) {
        var owned = state.generators[gen.id] || 0;
        return Math.ceil(gen.baseCost * Math.pow(COST_GROWTH, owned));
    }

    function formatNumber(n) {
        n = Math.floor(n);
        if (n < 1000) return String(n);
        var units = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi'];
        var order = Math.min(Math.floor(Math.log10(n) / 3), units.length - 1);
        var scaled = n / Math.pow(1000, order);
        return scaled.toFixed(scaled < 10 ? 2 : 1) + units[order];
    }

    // ================= DOM refs =================

    var screenAuth = document.getElementById('screen-auth');
    var screenGame = document.getElementById('screen-game');

    var authTabs = document.querySelectorAll('[data-auth-tab]');
    var loginForm = document.getElementById('login-form');
    var registerForm = document.getElementById('register-form');
    var authError = document.getElementById('auth-error');

    var el = {
        tiresStat: document.getElementById('stat-tires'),
        rateStat: document.getElementById('stat-rate'),
        tireButton: document.getElementById('tire-button'),
        carStage: document.getElementById('car-stage'),
        carFaces: document.querySelectorAll('.car-face'),
        shopGenerators: document.getElementById('shop-generators'),
        shopUpgrades: document.getElementById('shop-upgrades'),
        saveIndicator: document.getElementById('save-indicator'),
        topbarUsername: document.getElementById('topbar-username'),
        logoutButton: document.getElementById('logout-button'),
        tireFaces: document.querySelectorAll('.tire-face'),
        tireButtonLabel: document.getElementById('tire-button-label')
    };

    // ================= API helpers =================

    function apiGet(url) {
        return fetch(url, { credentials: 'same-origin' }).then(function (res) { return res.json(); });
    }

    function apiPost(url, body) {
        return fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        }).then(function (res) { return res.json(); });
    }

    // ================= Auth screen =================

    function showAuthError(message) {
        authError.textContent = message;
        authError.classList.remove('is-hidden');
    }

    function clearAuthError() {
        authError.classList.add('is-hidden');
        authError.textContent = '';
    }

    function switchAuthTab(target) {
        clearAuthError();
        authTabs.forEach(function (tab) {
            tab.classList.toggle('is-active', tab.getAttribute('data-auth-tab') === target);
        });
        loginForm.classList.toggle('is-hidden', target !== 'login');
        registerForm.classList.toggle('is-hidden', target !== 'register');
    }

    function initAuthScreen() {
        authTabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                switchAuthTab(tab.getAttribute('data-auth-tab'));
            });
        });

        loginForm.addEventListener('submit', function (evt) {
            evt.preventDefault();
            clearAuthError();
            var submitBtn = loginForm.querySelector('button[type="submit"]');
            submitBtn.disabled = true;

            apiPost('api/login.php', {
                csrf_token: csrfToken,
                username: loginForm.username.value,
                password: loginForm.password.value
            }).then(function (data) {
                submitBtn.disabled = false;
                if (data.ok) {
                    enterGame(data.username);
                } else {
                    showAuthError(data.error || 'Could not log in.');
                }
            }).catch(function () {
                submitBtn.disabled = false;
                showAuthError('Could not reach the server.');
            });
        });

        registerForm.addEventListener('submit', function (evt) {
            evt.preventDefault();
            clearAuthError();
            var submitBtn = registerForm.querySelector('button[type="submit"]');
            submitBtn.disabled = true;

            apiPost('api/register.php', {
                csrf_token: csrfToken,
                username: registerForm.username.value,
                password: registerForm.password.value,
                confirm: registerForm.confirm.value
            }).then(function (data) {
                submitBtn.disabled = false;
                if (data.ok) {
                    enterGame(data.username);
                } else {
                    showAuthError(data.error || 'Could not create an account.');
                }
            }).catch(function () {
                submitBtn.disabled = false;
                showAuthError('Could not reach the server.');
            });
        });
    }

    function showAuthScreen() {
        screenGame.classList.add('is-hidden');
        screenAuth.classList.remove('is-hidden');
        switchAuthTab('login');
    }

    // ================= Game screen wiring =================

    function wheelSlots() {
        var face = el.carStage.querySelector('.car-face.is-active');
        return face ? face.querySelectorAll('.wheel-slot') : [];
    }

    function refreshTopStats() {
        el.tiresStat.textContent = formatNumber(state.tires) + ' tires';
        el.rateStat.textContent = formatNumber(tiresPerSecond()) + ' tires/sec';
    }

    function refreshWheelVisual() {
        var slots = wheelSlots();
        for (var i = 0; i < slots.length; i++) {
            if (i < state.wheelsOnCurrentCar) {
                slots[i].classList.add('is-mounted');
            } else {
                slots[i].classList.remove('is-mounted');
            }
        }
    }

    function refreshVehicleTier() {
        var tier = Math.min(state.clickUpgrades.length, TIRE_TIER_NAMES.length - 1);
        el.tireFaces.forEach(function (face) {
            var faceTier = Number(face.getAttribute('data-tire-tier'));
            face.classList.toggle('is-active', faceTier === tier);
        });
        el.carFaces.forEach(function (face) {
            var faceTier = Number(face.getAttribute('data-car-tier'));
            face.classList.toggle('is-active', faceTier === tier);
        });
        if (el.tireButtonLabel) {
            el.tireButtonLabel.textContent = TIRE_TIER_NAMES[tier];
        }
        refreshWheelVisual();
    }

    function completeCarIfReady() {
        if (state.wheelsOnCurrentCar < 2) return;
        state.carsCompleted += 1;
        el.carStage.classList.add('is-complete');
        setTimeout(function () {
            state.wheelsOnCurrentCar = 0;
            el.carStage.classList.remove('is-complete');
            refreshWheelVisual();
        }, 500);
    }

    function mountTires(amount) {
        state.tires += amount;
        state.totalTires += amount;
        var remaining = amount;
        while (remaining > 0 && state.wheelsOnCurrentCar < 2) {
            state.wheelsOnCurrentCar += 1;
            remaining -= 1;
        }
        refreshWheelVisual();
        completeCarIfReady();
        refreshTopStats();
    }

    function spawnClickPop(x, y, amount) {
        var pop = document.createElement('div');
        pop.className = 'click-pop';
        pop.textContent = '+' + formatNumber(amount);
        pop.style.left = x + 'px';
        pop.style.top = y + 'px';
        document.body.appendChild(pop);
        setTimeout(function () { pop.remove(); }, 700);
    }

    // ---------- Shop ----------

    function buyGenerator(gen) {
        var cost = generatorCost(gen);
        if (state.tires < cost) return;
        state.tires -= cost;
        state.generators[gen.id] = (state.generators[gen.id] || 0) + 1;
        refreshTopStats();
        renderShop();
        queueSave();
    }

    function buyClickUpgrade(upg) {
        if (state.clickUpgrades.indexOf(upg.id) !== -1) return;
        if (state.tires < upg.cost) return;
        state.tires -= upg.cost;
        state.clickUpgrades.push(upg.id);
        refreshTopStats();
        refreshVehicleTier();
        renderShop();
        queueSave();
    }

    function renderShop() {
        renderGeneratorList();
        renderUpgradeList();
    }

    function renderGeneratorList() {
        el.shopGenerators.innerHTML = '';
        for (var i = 0; i < GENERATORS.length; i++) {
            var gen = GENERATORS[i];
            var owned = state.generators[gen.id] || 0;
            var cost = generatorCost(gen);
            var afford = state.tires >= cost;

            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'shop-item' + (afford ? ' can-afford' : '');
            btn.disabled = !afford;

            var top = document.createElement('div');
            top.className = 'shop-item-top';
            var name = document.createElement('span');
            name.className = 'shop-item-name';
            name.textContent = gen.name;
            var count = document.createElement('span');
            count.className = 'shop-item-count';
            count.textContent = owned > 0 ? ('x' + owned) : '';
            top.appendChild(name);
            top.appendChild(count);

            var desc = document.createElement('p');
            desc.className = 'shop-item-desc';
            desc.textContent = formatNumber(gen.rate) + ' tires/sec each';

            var costEl = document.createElement('span');
            costEl.className = 'shop-item-cost';
            var costText = document.createElement('span');
            costText.textContent = formatNumber(cost) + ' tires';
            costEl.appendChild(costText);

            btn.appendChild(top);
            btn.appendChild(desc);
            btn.appendChild(costEl);
            btn.addEventListener('click', (function (g) {
                return function () { buyGenerator(g); };
            })(gen));

            el.shopGenerators.appendChild(btn);
        }
    }

    function renderUpgradeList() {
        el.shopUpgrades.innerHTML = '';
        var anyLeft = false;
        for (var i = 0; i < CLICK_UPGRADES.length; i++) {
            var upg = CLICK_UPGRADES[i];
            var owned = state.clickUpgrades.indexOf(upg.id) !== -1;
            if (owned) continue;
            anyLeft = true;

            var afford = state.tires >= upg.cost;
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'shop-item' + (afford ? ' can-afford' : '');
            btn.disabled = !afford;

            var top = document.createElement('div');
            top.className = 'shop-item-top';
            var name = document.createElement('span');
            name.className = 'shop-item-name';
            name.textContent = upg.name;
            top.appendChild(name);

            var desc = document.createElement('p');
            desc.className = 'shop-item-desc';
            desc.textContent = '+' + upg.add + ' per click';

            var costEl = document.createElement('span');
            costEl.className = 'shop-item-cost';
            var costText = document.createElement('span');
            costText.textContent = formatNumber(upg.cost) + ' tires';
            costEl.appendChild(costText);

            btn.appendChild(top);
            btn.appendChild(desc);
            btn.appendChild(costEl);
            btn.addEventListener('click', (function (u) {
                return function () { buyClickUpgrade(u); };
            })(upg));

            el.shopUpgrades.appendChild(btn);
        }

        if (!anyLeft) {
            var done = document.createElement('p');
            done.className = 'shop-empty';
            done.textContent = 'Every garage upgrade is installed. Click power maxed for now.';
            el.shopUpgrades.appendChild(done);
        }
    }

    // ---------- Save/load ----------

    var saveTimer = null;
    var tickInterval = null;
    var shopInterval = null;
    var saveInterval = null;

    function queueSave() {
        if (saveTimer) clearTimeout(saveTimer);
        saveTimer = setTimeout(persist, 800);
    }

    function persist() {
        el.saveIndicator.textContent = 'saving...';
        el.saveIndicator.classList.add('is-saving');

        apiPost('api/save.php', {
            csrf_token: csrfToken,
            state: {
                tires: state.tires,
                totalTires: state.totalTires,
                clickPower: clickPower(),
                generators: state.generators,
                clickUpgrades: state.clickUpgrades,
                carsCompleted: state.carsCompleted,
                wheelsOnCurrentCar: state.wheelsOnCurrentCar
            }
        }).then(function (data) {
            el.saveIndicator.classList.remove('is-saving');
            el.saveIndicator.textContent = data.ok ? 'saved' : 'save failed';
        }).catch(function () {
            el.saveIndicator.classList.remove('is-saving');
            el.saveIndicator.textContent = 'offline';
        });
    }

    // ---------- Game wiring ----------

    function initTireButton() {
        el.tireButton.addEventListener('click', function (evt) {
            var amount = clickPower();
            mountTires(amount);
            var rect = el.tireButton.getBoundingClientRect();
            spawnClickPop(
                (evt.clientX || (rect.left + rect.width / 2)),
                (evt.clientY || rect.top),
                amount
            );
            queueSave();
        });
    }

    function initShopTabs() {
        var tabs = document.querySelectorAll('[data-shop-tab]');
        tabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                tabs.forEach(function (t) { t.classList.remove('is-active'); });
                tab.classList.add('is-active');
                var target = tab.getAttribute('data-shop-tab');
                el.shopGenerators.classList.toggle('is-hidden', target !== 'generators');
                el.shopUpgrades.classList.toggle('is-hidden', target !== 'upgrades');
            });
        });
    }

    function tick() {
        var perSecond = tiresPerSecond();
        if (perSecond > 0) {
            mountTires(perSecond / 10);
        }
        refreshTopStats();
    }

    function startGameLoops() {
        stopGameLoops();
        tickInterval = setInterval(tick, 100);
        shopInterval = setInterval(renderShop, 500);
        saveInterval = setInterval(queueSave, 6000);
    }

    function stopGameLoops() {
        if (tickInterval) clearInterval(tickInterval);
        if (shopInterval) clearInterval(shopInterval);
        if (saveInterval) clearInterval(saveInterval);
    }

    function resetGameDom() {
        state = {
            tires: 0,
            totalTires: 0,
            generators: {},
            clickUpgrades: [],
            carsCompleted: 0,
            wheelsOnCurrentCar: 0
        };
    }

    function enterGame(username) {
        screenAuth.classList.add('is-hidden');
        screenGame.classList.remove('is-hidden');
        el.topbarUsername.textContent = username || '';

        apiGet('api/load.php').then(function (data) {
            resetGameDom();
            if (data.ok && data.state) {
                applyServerState(data.state);
            }
            refreshTopStats();
            refreshVehicleTier();
            renderShop();
            startGameLoops();
        });
    }

    function resetAuthForms() {
        loginForm.reset();
        registerForm.reset();
        clearAuthError();
    }

    function initLogout() {
        el.logoutButton.addEventListener('click', function () {
            stopGameLoops();
            apiPost('api/logout.php', {}).then(function () {
                resetGameDom();
                resetAuthForms();
                bootstrap();
            });
        });
    }

    // ================= Bootstrap =================

    function bootstrap() {
        apiGet('api/session.php').then(function (data) {
            csrfToken = data.csrf_token;
            if (data.loggedIn) {
                enterGame(data.username);
            } else {
                showAuthScreen();
            }
        }).catch(function () {
            showAuthScreen();
            showAuthError('Could not reach the server.');
        });
    }

    function init() {
        initTheme();
        initAuthScreen();
        initTireButton();
        initShopTabs();
        initLogout();
        window.addEventListener('beforeunload', function () {
            if (!screenGame.classList.contains('is-hidden')) persist();
        });
        bootstrap();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
