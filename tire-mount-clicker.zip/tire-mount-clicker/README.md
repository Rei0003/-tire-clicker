# Tire Clicker

A clicker game: click the tire to mount it, hire crew and buy equipment to
mount tires for you, and buy garage upgrades to move your car and tire up
through 11 tiers. Accounts, login, and saved progress are handled by a few
small PHP files; everything else is plain HTML, CSS and JavaScript.

## Running it

You need PHP 7.4+ with the **`pdo_sqlite`** extension enabled. From this folder:

```bash
php -S localhost:8000
```

Then open http://localhost:8000. Open it through the server like this — the
page loads its HTML pieces with `fetch()`, so double-clicking `index.html`
will not work.

If sign-up says "could not find driver", enable SQLite in `php.ini`
(`php --ini` shows where it is) by removing the `;` from
`extension=pdo_sqlite` and `extension=sqlite3`, then restart the server.

On a normal web host, just upload the whole folder; a `data/` folder holding
the SQLite save file is created automatically (make sure PHP can write to the
project folder).

## Where things are

```
index.html            tiny shell: <head> links + two include slots
partials/             the page's HTML, one piece per file
  auth.html             sign in / register screen
  game.html             game screen (assembles the pieces below)
  topbar.html           title, tire counter, save status, sign out
  controls.html         music + light/dark buttons (used on both screens)
  stage.html            click area (lists which car/tire files to use)
  shop.html             shop tabs + lists
  cars/  00-sedan.html … 10-record-car.html      one car per tier
  tires/ 00-street-tire.html … 10-record-wheel.html   one tire per tier
css/                  styles, one file per area
  tokens.css            colours for light + dark (change the look here)
  base.css              reset, page defaults, tiny utilities
  controls.css          round music/theme buttons
  auth.css  topbar.css  layout.css  stage.css  shop.css
js/                   the game, one job per file
  main.js               entry point: loads partials, starts everything
  config.js             ALL game numbers, upgrade/crew lists, music list
  state.js              player progress + calculations (click power, costs)
  game.js               click loop, idle tick, sign out
  shop.js               the two shop lists and buying
  vehicle.js            which car/tire shows, mounting wheels
  music.js              background music + on/off button
  theme.js              light/dark button     theme-boot.js  applies saved theme early
  auth.js               sign in / register    save.js        talks to api/save.php
  hud.js  dom.js  api.js  session.js  format.js  partials.js   small helpers
assets/music/         the three background tracks
api/  includes/       PHP: accounts, sessions, save/load (SQLite)
```

## Common changes

- **Prices, crew, upgrades** — `js/config.js` (`GENERATORS`, `CLICK_UPGRADES`).
- **Colours / dark and light look** — `css/tokens.css`.
- **Music** — put an mp3 in `assets/music/` and add it to `MUSIC.tracks` in
  `js/config.js`. Volume is `MUSIC.volume` (0 to 1). Tracks play in order and
  loop. Browsers block sound until you click something, so music starts on
  your first click; the speaker button turns it on/off and remembers the choice.
- **Add a car/tire tier** — add `NN-name.html` to `partials/cars/` and
  `partials/tires/` (copy an existing one, change `data-car-tier` /
  `data-tire-tier`, keep exactly two `.wheel-slot` circles in each car),
  list them in `partials/stage.html`, then add one entry to `CLICK_UPGRADES`
  and one name to `TIRE_TIER_NAMES` in `js/config.js`.

## Security notes

Made for a personal/small project: hashed passwords, prepared statements, a
CSRF token on every state-changing request, and session-gated save/load. If
you put it on the public internet, use HTTPS and consider rate-limiting logins.
