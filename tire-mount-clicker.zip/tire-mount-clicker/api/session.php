<?php
declare(strict_types=1);
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

try {
    echo json_encode([
        'ok' => true,
        'loggedIn' => current_user_id() !== null,
        'username' => current_username(),
        'csrf_token' => csrf_token(),
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
