<?php
declare(strict_types=1);
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['ok' => false, 'error' => 'Method not allowed.']);
        exit;
    }

    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) {
        $body = [];
    }

    if (!check_csrf((string) ($body['csrf_token'] ?? ''))) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Session expired, please reload the page.']);
        exit;
    }

    [$success, $message] = register_user(
        (string) ($body['username'] ?? ''),
        (string) ($body['password'] ?? ''),
        (string) ($body['confirm'] ?? '')
    );

    if (!$success) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => $message]);
        exit;
    }

    echo json_encode(['ok' => true, 'username' => current_username()]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
