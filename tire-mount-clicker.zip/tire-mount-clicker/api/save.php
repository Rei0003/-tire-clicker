<?php
declare(strict_types=1);
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

try {
    require_login_or_401();

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['ok' => false, 'error' => 'Method not allowed.']);
        exit;
    }

    $payload = json_decode(file_get_contents('php://input'), true);
    if (!is_array($payload) || !check_csrf((string) ($payload['csrf_token'] ?? ''))) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Invalid session token.']);
        exit;
    }

    $state = $payload['state'] ?? null;
    if (!is_array($state)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Malformed state.']);
        exit;
    }

    // Basic sanity limits so a tampered client can't write absurd/garbage values.
    $clean = [
        'tires' => max(0.0, (float) ($state['tires'] ?? 0)),
        'totalTires' => max(0.0, (float) ($state['totalTires'] ?? 0)),
        'clickPower' => max(1.0, min((float) ($state['clickPower'] ?? 1), 1_000_000_000)),
        'generators' => is_array($state['generators'] ?? null) ? $state['generators'] : new stdClass(),
        'clickUpgrades' => is_array($state['clickUpgrades'] ?? null) ? array_values($state['clickUpgrades']) : [],
        'carsCompleted' => max(0, (int) ($state['carsCompleted'] ?? 0)),
        'wheelsOnCurrentCar' => max(0, min(2, (int) ($state['wheelsOnCurrentCar'] ?? 0))),
    ];

    $pdo = get_db();
    $stmt = $pdo->prepare('
        INSERT INTO saves (user_id, state, updated_at) VALUES (:uid, :state, CURRENT_TIMESTAMP)
        ON CONFLICT(user_id) DO UPDATE SET state = excluded.state, updated_at = CURRENT_TIMESTAMP
    ');
    $stmt->execute([
        'uid' => current_user_id(),
        'state' => json_encode($clean),
    ]);

    echo json_encode(['ok' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
