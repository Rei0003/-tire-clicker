<?php
declare(strict_types=1);
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

try {
    require_login_or_401();

    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT state, updated_at FROM saves WHERE user_id = :uid');
    $stmt->execute(['uid' => current_user_id()]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(['ok' => true, 'state' => null]);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'state' => json_decode($row['state'], true),
        'updated_at' => $row['updated_at'],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
