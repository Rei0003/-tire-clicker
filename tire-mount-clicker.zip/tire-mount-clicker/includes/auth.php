<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function current_user_id(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

function current_username(): ?string
{
    return $_SESSION['username'] ?? null;
}

function require_login_or_401(): void
{
    if (current_user_id() === null) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'Not logged in.']);
        exit;
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function check_csrf(string $token): bool
{
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * @return array{0: bool, 1: string} [success, message]
 */
function register_user(string $username, string $password, string $confirm): array
{
    $username = trim($username);

    if ($username === '' || $password === '') {
        return [false, 'Username and password are required.'];
    }
    if (!preg_match('/^[A-Za-z0-9_\-]{3,20}$/', $username)) {
        return [false, 'Username must be 3-20 characters: letters, numbers, - or _ only.'];
    }
    if (strlen($password) < 6) {
        return [false, 'Password must be at least 6 characters.'];
    }
    if ($password !== $confirm) {
        return [false, 'Passwords do not match.'];
    }

    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = :u');
    $stmt->execute(['u' => $username]);
    if ($stmt->fetch()) {
        return [false, 'That username is already mounted. Pick another.'];
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash) VALUES (:u, :p)');
    $stmt->execute(['u' => $username, 'p' => $hash]);
    $userId = (int) $pdo->lastInsertId();

    $initialState = json_encode([
        'tires' => 0,
        'totalTires' => 0,
        'clickPower' => 1,
        'generators' => new stdClass(),
        'clickUpgrades' => [],
        'carsCompleted' => 0,
        'wheelsOnCurrentCar' => 0,
    ]);
    $stmt = $pdo->prepare('INSERT INTO saves (user_id, state) VALUES (:uid, :state)');
    $stmt->execute(['uid' => $userId, 'state' => $initialState]);

    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;

    return [true, 'Account created.'];
}

/**
 * @return array{0: bool, 1: string}
 */
function login_user(string $username, string $password): array
{
    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT id, username, password_hash FROM users WHERE username = :u');
    $stmt->execute(['u' => trim($username)]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return [false, 'Wrong username or password.'];
    }

    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['username'] = $user['username'];

    return [true, 'Welcome back.'];
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie('PHPSESSID', '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
