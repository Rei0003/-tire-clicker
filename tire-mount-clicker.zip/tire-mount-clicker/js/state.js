// The player's progress, plus the small calculations based on it.
import { GENERATORS, CLICK_UPGRADES, COST_GROWTH, WHEELS_PER_CAR } from './config.js';

function freshState() {
    return {
        tires: 0,
        totalTires: 0,
        generators: {},          // { generatorId: howManyOwned }
        clickUpgrades: [],       // [upgradeId, ...]
        carsCompleted: 0,
        wheelsOnCurrentCar: 0
    };
}

// One shared object. Other files import it and read/change it directly.
export const state = freshState();

export function resetState() {
    Object.assign(state, freshState());
}

// Copy a save from the server into `state`, tolerating missing/odd values.
export function applyServerState(saved) {
    saved = saved || {};
    state.tires = Number(saved.tires) || 0;
    state.totalTires = Number(saved.totalTires) || 0;
    state.generators = (saved.generators && typeof saved.generators === 'object') ? saved.generators : {};
    state.clickUpgrades = Array.isArray(saved.clickUpgrades) ? saved.clickUpgrades : [];
    state.carsCompleted = Number(saved.carsCompleted) || 0;
    state.wheelsOnCurrentCar = Math.max(0, Math.min(WHEELS_PER_CAR, Number(saved.wheelsOnCurrentCar) || 0));
}

// What gets sent to api/save.php.
export function serializeState() {
    return {
        tires: state.tires,
        totalTires: state.totalTires,
        clickPower: clickPower(),
        generators: state.generators,
        clickUpgrades: state.clickUpgrades,
        carsCompleted: state.carsCompleted,
        wheelsOnCurrentCar: state.wheelsOnCurrentCar
    };
}

export function clickPower() {
    let power = 1;
    for (const upgrade of CLICK_UPGRADES) {
        if (state.clickUpgrades.includes(upgrade.id)) power += upgrade.add;
    }
    return power;
}

export function tiresPerSecond() {
    let rate = 0;
    for (const gen of GENERATORS) {
        rate += (state.generators[gen.id] || 0) * gen.rate;
    }
    return rate;
}

export function generatorCost(gen) {
    const owned = state.generators[gen.id] || 0;
    return Math.ceil(gen.baseCost * Math.pow(COST_GROWTH, owned));
}
