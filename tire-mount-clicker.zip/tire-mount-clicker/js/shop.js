// The two shop lists: crew & equipment (per-second) and garage upgrades (per-click).
import { GENERATORS, CLICK_UPGRADES } from './config.js';
import { state, generatorCost } from './state.js';
import { formatNumber } from './format.js';
import { el } from './dom.js';
import { refreshTopStats } from './hud.js';
import { refreshVehicleTier } from './vehicle.js';
import { queueSave } from './save.js';

function buyGenerator(gen) {
    const cost = generatorCost(gen);
    if (state.tires < cost) return;

    state.tires -= cost;
    state.generators[gen.id] = (state.generators[gen.id] || 0) + 1;
    refreshTopStats();
    renderShop();
    queueSave();
}

function buyClickUpgrade(upgrade) {
    if (state.clickUpgrades.includes(upgrade.id)) return;
    if (state.tires < upgrade.cost) return;

    state.tires -= upgrade.cost;
    state.clickUpgrades.push(upgrade.id);
    refreshTopStats();
    refreshVehicleTier();   // a new upgrade moves the car + tire up a tier
    renderShop();
    queueSave();
}

// One row: name (+ optional count), a short description and the price.
function buildRow({ name, count, description, cost, affordable, onBuy }) {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'shop-item' + (affordable ? ' can-afford' : '');
    row.disabled = !affordable;

    const top = document.createElement('div');
    top.className = 'shop-item-top';

    const nameEl = document.createElement('span');
    nameEl.className = 'shop-item-name';
    nameEl.textContent = name;
    top.appendChild(nameEl);

    if (count !== undefined) {
        const countEl = document.createElement('span');
        countEl.className = 'shop-item-count';
        countEl.textContent = count;
        top.appendChild(countEl);
    }

    const descEl = document.createElement('p');
    descEl.className = 'shop-item-desc';
    descEl.textContent = description;

    const costEl = document.createElement('span');
    costEl.className = 'shop-item-cost';
    const costText = document.createElement('span');
    costText.textContent = formatNumber(cost) + ' tires';
    costEl.appendChild(costText);

    row.append(top, descEl, costEl);
    row.addEventListener('click', onBuy);
    return row;
}

function renderGeneratorList() {
    el.shopGenerators.innerHTML = '';
    for (const gen of GENERATORS) {
        const owned = state.generators[gen.id] || 0;
        const cost = generatorCost(gen);
        el.shopGenerators.appendChild(buildRow({
            name: gen.name,
            count: owned > 0 ? 'x' + owned : '',
            description: formatNumber(gen.rate) + ' tires/sec each',
            cost: cost,
            affordable: state.tires >= cost,
            onBuy: () => buyGenerator(gen)
        }));
    }
}

function renderUpgradeList() {
    el.shopUpgrades.innerHTML = '';
    let anyLeft = false;

    for (const upgrade of CLICK_UPGRADES) {
        if (state.clickUpgrades.includes(upgrade.id)) continue;
        anyLeft = true;
        el.shopUpgrades.appendChild(buildRow({
            name: upgrade.name,
            description: '+' + upgrade.add.toLocaleString() + ' per click',
            cost: upgrade.cost,
            affordable: state.tires >= upgrade.cost,
            onBuy: () => buyClickUpgrade(upgrade)
        }));
    }

    if (!anyLeft) {
        const done = document.createElement('p');
        done.className = 'shop-empty';
        done.textContent = 'Every garage upgrade is installed. Click power maxed for now.';
        el.shopUpgrades.appendChild(done);
    }
}

export function renderShop() {
    renderGeneratorList();
    renderUpgradeList();
}

export function initShopTabs() {
    el.shopTabs.forEach((tab) => {
        tab.addEventListener('click', () => {
            el.shopTabs.forEach((t) => t.classList.remove('is-active'));
            tab.classList.add('is-active');
            const target = tab.dataset.shopTab;
            el.shopGenerators.classList.toggle('is-hidden', target !== 'generators');
            el.shopUpgrades.classList.toggle('is-hidden', target !== 'upgrades');
        });
    });
}
