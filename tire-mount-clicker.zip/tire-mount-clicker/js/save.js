// Saving progress to the server (api/save.php).
import { SAVE_DEBOUNCE_MS } from './config.js';
import { serializeState } from './state.js';
import { session } from './session.js';
import { apiPost } from './api.js';
import { el } from './dom.js';

let saveTimer = null;

// Save shortly after the last change, so rapid clicking makes one request.
export function queueSave() {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(persist, SAVE_DEBOUNCE_MS);
}

export function persist() {
    el.saveIndicator.textContent = 'saving...';
    el.saveIndicator.classList.add('is-saving');

    apiPost('api/save.php', {
        csrf_token: session.csrfToken,
        state: serializeState()
    }).then((data) => {
        el.saveIndicator.classList.remove('is-saving');
        el.saveIndicator.textContent = data.ok ? 'saved' : 'save failed';
    }).catch(() => {
        el.saveIndicator.classList.remove('is-saving');
        el.saveIndicator.textContent = 'offline';
    });
}
