// Small shared holder for the CSRF token we get from api/session.php.
export const session = { csrfToken: null };
