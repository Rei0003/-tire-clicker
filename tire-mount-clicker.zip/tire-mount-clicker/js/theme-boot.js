// Runs in <head> BEFORE the page paints, so a saved light theme never flashes dark.
// (The toggle buttons themselves are wired up in js/theme.js.)
(function () {
    var stored = null;
    try { stored = localStorage.getItem('tire-clicker-theme'); } catch (e) { /* ignore */ }

    var theme = stored;
    if (!theme) {
        theme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches)
            ? 'light' : 'dark';
    }
    if (theme === 'light') document.documentElement.setAttribute('data-theme', 'light');
})();
