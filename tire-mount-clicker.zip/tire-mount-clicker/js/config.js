// Everything you would tweak to rebalance, extend or re-theme the game lives here.

// ---- Crew & equipment: auto-mount tires every second ----
// baseCost: price of the first one (each extra costs COST_GROWTH x more)
// rate:     tires per second each one adds
export const GENERATORS = [
    { id: 'rookie', name: 'Rookie Mechanic', baseCost: 15, rate: 1 },
    { id: 'wrenchStation', name: 'Impact Wrench Station', baseCost: 100, rate: 5 },
    { id: 'balancer', name: 'Tire Balancer Rig', baseCost: 600, rate: 20 },
    { id: 'secondBay', name: 'Another Bay', baseCost: 4000, rate: 80 },
    { id: 'pitCrew', name: 'Pit Crew Team', baseCost: 20000, rate: 300 },
    { id: 'hydraulicLine', name: 'Hydraulic Lift Line', baseCost: 100000, rate: 1000 },
    { id: 'deliveryFleet', name: 'Delivery Fleet', baseCost: 500000, rate: 4000 },
    { id: 'warehouse', name: 'Regional Warehouse', baseCost: 2500000, rate: 15000 },
    { id: 'franchise', name: 'National Franchise', baseCost: 12000000, rate: 60000 }
];

// ---- Garage upgrades: one-time purchases that raise tires per click ----
// Each one you own also moves the car + tire up a tier (see TIRE_TIER_NAMES),
// so the list needs (number of car files in partials/cars) - 1 entries.
export const CLICK_UPGRADES = [
    { id: 'boots', name: 'Steel-Toe Boots', cost: 50, add: 1 },
    { id: 'pneumatic', name: 'Pneumatic Wrench', cost: 500, add: 4 },
    { id: 'jack', name: 'Hydraulic Jack', cost: 5000, add: 10 },
    { id: 'roboticArm', name: 'Robotic Torque Arm', cost: 50000, add: 50 },
    { id: 'autoBay', name: 'Full Auto Bay', cost: 500000, add: 250 },
    { id: 'nitrogen', name: 'Nitrogen Tire Filler', cost: 2000000, add: 1000 },
    { id: 'laserAlign', name: 'Laser Wheel Aligner', cost: 10000000, add: 5000 },
    { id: 'titanLift', name: 'Titan Lift System', cost: 50000000, add: 25000 },
    { id: 'aiAssist', name: 'AI Tire Assistant', cost: 250000000, add: 100000 },
    { id: 'quantumRig', name: 'Quantum Torque Rig', cost: 1000000000, add: 500000 }
];

// Label under the tire button for each tier (index 0 = no upgrades bought yet).
export const TIRE_TIER_NAMES = [
    'Street Tire', 'Street Wheel', 'Sport Wheel', 'Off-Road Wheel', 'Racing Wheel', 'Rally Wheel',
    'Supercar Wheel', 'Drag Slick', 'Monster Tire', 'Hypercar Wheel', 'Record Wheel'
];

export const COST_GROWTH = 1.15;   // each extra crew/equipment costs 15% more
export const WHEELS_PER_CAR = 2;   // tires it takes to finish one car

// ---- Timing (milliseconds) ----
export const TICK_MS = 100;           // how often crew add tires
export const SHOP_REFRESH_MS = 500;   // how often shop rows re-check what you can afford
export const AUTOSAVE_MS = 6000;      // periodic save
export const SAVE_DEBOUNCE_MS = 800;  // save this long after your last click/purchase
export const CAR_EXIT_MS = 500;       // must match the drive-off animation in css/stage.css

// ---- Browser storage keys ----
// (js/theme-boot.js repeats the theme key because it runs before modules load)
export const THEME_KEY = 'tire-clicker-theme';

// ---- Background music ----
// Tracks play in order and loop. Drop more mp3s in assets/music/ and list them here.
export const MUSIC = {
    storageKey: 'tire-clicker-music',
    volume: 0.3,
    tracks: [
        'assets/music/background-music.mp3',
        'assets/music/driving-beat.mp3',
        'assets/music/rock-instrumental.mp3'
    ]
};
