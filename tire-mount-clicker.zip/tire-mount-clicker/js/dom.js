// One place that looks up the page's elements. Call collectElements() once,
// AFTER js/partials.js has loaded the HTML, then import `el` anywhere.
export const el = {};

const byId = (id) => document.getElementById(id);

export function collectElements() {
    Object.assign(el, {
        // screens + sign in / register
        screenAuth: byId('screen-auth'),
        screenGame: byId('screen-game'),
        authTabs: document.querySelectorAll('[data-auth-tab]'),
        loginForm: byId('login-form'),
        registerForm: byId('register-form'),
        authError: byId('auth-error'),

        // topbar
        tiresStat: byId('stat-tires'),
        rateStat: byId('stat-rate'),
        saveIndicator: byId('save-indicator'),
        topbarUsername: byId('topbar-username'),
        logoutButton: byId('logout-button'),

        // click area
        carStage: byId('car-stage'),
        carFaces: document.querySelectorAll('.car-face'),
        tireButton: byId('tire-button'),
        tireFaces: document.querySelectorAll('.tire-face'),
        tireButtonLabel: byId('tire-button-label'),

        // shop
        shopTabs: document.querySelectorAll('[data-shop-tab]'),
        shopGenerators: byId('shop-generators'),
        shopUpgrades: byId('shop-upgrades')
    });
}
