// The numbers in the topbar.
import { state, tiresPerSecond } from './state.js';
import { formatNumber } from './format.js';
import { el } from './dom.js';

export function refreshTopStats() {
    el.tiresStat.textContent = formatNumber(state.tires) + ' tires';
    el.rateStat.textContent = formatNumber(tiresPerSecond()) + ' tires/sec';
}
