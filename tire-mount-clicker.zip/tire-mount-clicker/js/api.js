// Thin wrappers around fetch() for the PHP JSON endpoints in api/.
export function apiGet(url) {
    return fetch(url, { credentials: 'same-origin' }).then((res) => res.json());
}

export function apiPost(url, body) {
    return fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    }).then((res) => res.json());
}
