// The car in the bay and the tire button: which tier is showing, mounting
// wheels onto the car, and the "+N" pop when you click.
import { TIRE_TIER_NAMES, WHEELS_PER_CAR, CAR_EXIT_MS } from './config.js';
import { state } from './state.js';
import { el } from './dom.js';
import { formatNumber } from './format.js';
import { refreshTopStats } from './hud.js';

function activeWheelSlots() {
    const face = el.carStage.querySelector('.car-face.is-active');
    return face ? face.querySelectorAll('.wheel-slot') : [];
}

// Light up as many wheel slots on the car as have been mounted so far.
export function refreshWheelVisual() {
    const slots = activeWheelSlots();
    for (let i = 0; i < slots.length; i++) {
        slots[i].classList.toggle('is-mounted', i < state.wheelsOnCurrentCar);
    }
}

// Show the car + tire matching how many garage upgrades are owned.
export function refreshVehicleTier() {
    const tier = Math.min(state.clickUpgrades.length, TIRE_TIER_NAMES.length - 1);

    el.tireFaces.forEach((face) => {
        face.classList.toggle('is-active', Number(face.dataset.tireTier) === tier);
    });
    el.carFaces.forEach((face) => {
        face.classList.toggle('is-active', Number(face.dataset.carTier) === tier);
    });
    if (el.tireButtonLabel) {
        el.tireButtonLabel.textContent = TIRE_TIER_NAMES[tier];
    }
    refreshWheelVisual();
}

function completeCarIfReady() {
    if (state.wheelsOnCurrentCar < WHEELS_PER_CAR) return;

    state.carsCompleted += 1;
    el.carStage.classList.add('is-complete');   // plays the drive-off animation
    setTimeout(() => {
        state.wheelsOnCurrentCar = 0;
        el.carStage.classList.remove('is-complete');
        refreshWheelVisual();
    }, CAR_EXIT_MS);
}

// Add tires to your total and put them on the car.
export function mountTires(amount) {
    state.tires += amount;
    state.totalTires += amount;

    let remaining = amount;
    while (remaining > 0 && state.wheelsOnCurrentCar < WHEELS_PER_CAR) {
        state.wheelsOnCurrentCar += 1;
        remaining -= 1;
    }
    refreshWheelVisual();
    completeCarIfReady();
    refreshTopStats();
}

export function spawnClickPop(x, y, amount) {
    const pop = document.createElement('div');
    pop.className = 'click-pop';
    pop.textContent = '+' + formatNumber(amount);
    pop.style.left = x + 'px';
    pop.style.top = y + 'px';
    document.body.appendChild(pop);
    setTimeout(() => pop.remove(), 700);
}
