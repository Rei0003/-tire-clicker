// 1234 -> "1.23K", 5000000 -> "5.00M", ...
export function formatNumber(n) {
    n = Math.floor(n);
    if (n < 1000) return String(n);
    const units = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi'];
    const order = Math.min(Math.floor(Math.log10(n) / 3), units.length - 1);
    const scaled = n / Math.pow(1000, order);
    return scaled.toFixed(scaled < 10 ? 2 : 1) + units[order];
}
