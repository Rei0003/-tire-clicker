// Entry point. Loads the HTML partials, then wires every module together.
//
//   partials.js  loads partials/*.html into index.html
//   dom.js       finds the elements     config.js   game settings + music list
//   auth.js      sign in / register     game.js     click loop + sign out
//   shop.js      the two shop lists     vehicle.js  car + tire tiers
//   music.js     background music       theme.js    light/dark buttons
//   state.js     player progress        save.js     talks to api/save.php
import { loadPartials } from './partials.js';
import { collectElements } from './dom.js';
import { session } from './session.js';
import { apiGet } from './api.js';
import { initThemeToggles } from './theme.js';
import { initMusic } from './music.js';
import { initAuthScreen, showAuthScreen, showAuthError, resetAuthForms } from './auth.js';
import { initShopTabs } from './shop.js';
import { enterGame, initTireButton, initLogout, initSaveOnExit } from './game.js';

// Ask the server who we are: straight into the game if signed in, else the sign-in screen.
function checkSession() {
    apiGet('api/session.php').then((data) => {
        session.csrfToken = data.csrf_token;
        if (data.loggedIn) {
            enterGame(data.username);
        } else {
            showAuthScreen();
        }
    }).catch(() => {
        showAuthScreen();
        showAuthError('Could not reach the server.');
    });
}

function showLoadError(err) {
    const box = document.createElement('p');
    box.style.cssText = 'padding:24px;font:16px Roboto,sans-serif;color:#B3261E;';
    box.textContent = 'Tire Clicker could not start: ' + err.message +
        '. Open it through a web server (for example php -S localhost:8000), not by double-clicking the file.';
    document.body.appendChild(box);
}

async function start() {
    try {
        await loadPartials();
    } catch (err) {
        showLoadError(err);
        return;
    }

    collectElements();
    initThemeToggles();
    initMusic();
    initAuthScreen(enterGame);
    initShopTabs();
    initTireButton();
    initLogout(() => {
        resetAuthForms();
        checkSession();
    });
    initSaveOnExit();
    checkSession();
}

start();
