// The game screen: starting/stopping it, the click button, the idle tick, sign out.
import { TICK_MS, SHOP_REFRESH_MS, AUTOSAVE_MS } from './config.js';
import { state, resetState, applyServerState, clickPower, tiresPerSecond } from './state.js';
import { apiGet, apiPost } from './api.js';
import { el } from './dom.js';
import { refreshTopStats } from './hud.js';
import { refreshVehicleTier, mountTires, spawnClickPop } from './vehicle.js';
import { renderShop } from './shop.js';
import { queueSave, persist } from './save.js';

let tickTimer = null;
let shopTimer = null;
let saveTimer = null;

// Crew add tires a little at a time, every TICK_MS.
function tick() {
    const perSecond = tiresPerSecond();
    if (perSecond > 0) {
        mountTires(perSecond * TICK_MS / 1000);
    }
    refreshTopStats();
}

function stopGameLoops() {
    clearInterval(tickTimer);
    clearInterval(shopTimer);
    clearInterval(saveTimer);
}

function startGameLoops() {
    stopGameLoops();
    tickTimer = setInterval(tick, TICK_MS);
    shopTimer = setInterval(renderShop, SHOP_REFRESH_MS);
    saveTimer = setInterval(queueSave, AUTOSAVE_MS);
}

// Show the game and load this player's save.
export function enterGame(username) {
    el.screenAuth.classList.add('is-hidden');
    el.screenGame.classList.remove('is-hidden');
    el.topbarUsername.textContent = username || '';

    apiGet('api/load.php').then((data) => {
        resetState();
        if (data.ok && data.state) {
            applyServerState(data.state);
        }
        refreshTopStats();
        refreshVehicleTier();
        renderShop();
        startGameLoops();
    });
}

export function initTireButton() {
    el.tireButton.addEventListener('click', (evt) => {
        const amount = clickPower();
        mountTires(amount);

        const rect = el.tireButton.getBoundingClientRect();
        spawnClickPop(
            evt.clientX || (rect.left + rect.width / 2),
            evt.clientY || rect.top,
            amount
        );
        queueSave();
    });
}

// onSignedOut runs once the server has ended the session.
export function initLogout(onSignedOut) {
    el.logoutButton.addEventListener('click', () => {
        stopGameLoops();
        apiPost('api/logout.php', {}).then(() => {
            resetState();
            onSignedOut();
        });
    });
}

// Save one last time if the tab is closed while playing.
export function initSaveOnExit() {
    window.addEventListener('beforeunload', () => {
        if (!el.screenGame.classList.contains('is-hidden')) persist();
    });
}
