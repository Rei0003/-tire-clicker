// Background music: plays the tracks from config.js in order, looping the list.
// The on/off buttons (.music-toggle, one per screen) stay in sync and the choice
// is remembered between visits.
//
// Browsers refuse to play sound until you have interacted with the page, so if
// music is "on" but blocked, the first click or key press anywhere starts it.
import { MUSIC } from './config.js';

let audio = null;
let trackIndex = 0;
let wanted = true;      // what the player chose (saved between visits)
let blocked = false;    // wants music, but the browser has not allowed sound yet
let failures = 0;       // tracks in a row that failed to load
let waitingForGesture = false;

function readPreference() {
    try { return localStorage.getItem(MUSIC.storageKey) !== 'off'; } catch (e) { return true; }
}

function writePreference(on) {
    try { localStorage.setItem(MUSIC.storageKey, on ? 'on' : 'off'); } catch (e) { /* ignore */ }
}

function isOn() {
    return wanted && !blocked;
}

function refreshToggles() {
    document.querySelectorAll('.music-toggle').forEach((button) => {
        button.setAttribute('aria-pressed', String(isOn()));
        button.setAttribute('aria-label', isOn() ? 'Turn music off' : 'Turn music on');
    });
}

function getAudio() {
    if (audio) return audio;
    audio = new Audio();
    audio.preload = 'auto';
    audio.volume = MUSIC.volume;
    audio.addEventListener('ended', () => {
        failures = 0;
        playTrack(trackIndex + 1);
    });
    audio.addEventListener('error', onTrackError);
    return audio;
}

function onTrackError() {
    failures += 1;
    if (failures >= MUSIC.tracks.length) {
        console.warn('Music: none of the tracks in config.js could be loaded.');
        return;
    }
    playTrack(trackIndex + 1);
}

function playTrack(index) {
    trackIndex = (index + MUSIC.tracks.length) % MUSIC.tracks.length;
    getAudio().src = MUSIC.tracks[trackIndex];
    return start();
}

async function start() {
    const player = getAudio();
    if (!player.src) player.src = MUSIC.tracks[trackIndex];
    try {
        await player.play();
        blocked = false;
        stopWaitingForGesture();
    } catch (err) {
        if (err && err.name === 'NotAllowedError') {
            blocked = true;
            waitForGesture();
        } else if (!err || err.name !== 'AbortError') {
            console.warn('Music could not start:', err);
        }
    }
    refreshToggles();
}

// ---- "start on the first click or key press" ----

function onFirstGesture(evt) {
    // The music button handles its own click.
    if (evt.target instanceof Element && evt.target.closest('.music-toggle')) return;
    stopWaitingForGesture();
    if (wanted) start();
}

function waitForGesture() {
    if (waitingForGesture) return;
    waitingForGesture = true;
    document.addEventListener('click', onFirstGesture, true);
    document.addEventListener('keydown', onFirstGesture, true);
}

function stopWaitingForGesture() {
    waitingForGesture = false;
    document.removeEventListener('click', onFirstGesture, true);
    document.removeEventListener('keydown', onFirstGesture, true);
}

// ---- the on/off button ----

function onToggleClick() {
    if (blocked) {
        // Music was supposed to be on but the browser held it back; this click unlocks it.
        wanted = true;
        writePreference(true);
        start();
        return;
    }

    wanted = !wanted;
    writePreference(wanted);
    if (wanted) {
        start();
    } else {
        blocked = false;
        stopWaitingForGesture();
        if (audio) audio.pause();
    }
    refreshToggles();
}

export function initMusic() {
    wanted = readPreference();
    blocked = wanted;   // assume blocked until playback actually starts
    document.querySelectorAll('.music-toggle').forEach((button) => {
        button.addEventListener('click', onToggleClick);
    });
    refreshToggles();

    if (wanted) {
        trackIndex = Math.floor(Math.random() * MUSIC.tracks.length);
        playTrack(trackIndex);
    }
}
