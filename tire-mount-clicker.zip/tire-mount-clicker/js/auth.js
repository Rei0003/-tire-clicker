// The Sign In / Register screen.
import { session } from './session.js';
import { apiPost } from './api.js';
import { el } from './dom.js';

export function showAuthError(message) {
    el.authError.textContent = message;
    el.authError.classList.remove('is-hidden');
}

function clearAuthError() {
    el.authError.classList.add('is-hidden');
    el.authError.textContent = '';
}

function switchTab(target) {
    clearAuthError();
    el.authTabs.forEach((tab) => {
        tab.classList.toggle('is-active', tab.dataset.authTab === target);
    });
    el.loginForm.classList.toggle('is-hidden', target !== 'login');
    el.registerForm.classList.toggle('is-hidden', target !== 'register');
}

export function showAuthScreen() {
    el.screenGame.classList.add('is-hidden');
    el.screenAuth.classList.remove('is-hidden');
    switchTab('login');
}

// Empty the fields (used after signing out so old input does not linger).
export function resetAuthForms() {
    el.loginForm.reset();
    el.registerForm.reset();
    clearAuthError();
}

// Send a form to the server; call onSuccess(username) if it worked.
function submitForm(form, url, payload, failMessage, onSuccess) {
    clearAuthError();
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;

    apiPost(url, Object.assign({ csrf_token: session.csrfToken }, payload)).then((data) => {
        button.disabled = false;
        if (data.ok) {
            onSuccess(data.username);
        } else {
            showAuthError(data.error || failMessage);
        }
    }).catch(() => {
        button.disabled = false;
        showAuthError('Could not reach the server.');
    });
}

export function initAuthScreen(onSignedIn) {
    el.authTabs.forEach((tab) => {
        tab.addEventListener('click', () => switchTab(tab.dataset.authTab));
    });

    el.loginForm.addEventListener('submit', (evt) => {
        evt.preventDefault();
        submitForm(el.loginForm, 'api/login.php', {
            username: el.loginForm.elements.username.value,
            password: el.loginForm.elements.password.value
        }, 'Could not log in.', onSignedIn);
    });

    el.registerForm.addEventListener('submit', (evt) => {
        evt.preventDefault();
        submitForm(el.registerForm, 'api/register.php', {
            username: el.registerForm.elements.username.value,
            password: el.registerForm.elements.password.value,
            confirm: el.registerForm.elements.confirm.value
        }, 'Could not create an account.', onSignedIn);
    });
}
