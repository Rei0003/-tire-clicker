import { MUSIC } from './config.js';

let audio = null;
let trackIndex = 0;
let wanted = true;
let blocked = false;
let failures = 0;
let waitingForGesture = false;

function readPreference() {
    try { return localStorage.getItem(MUSIC.storageKey) !== 'off'; } catch (e) { return true; }
}

function writePreference(on) {
    try { localStorage.setItem(MUSIC.storageKey, on ? 'on' : 'off'); } catch (e) { }
}

function isOn() {
    return wanted && !blocked;
}

function refreshToggles() {
    document.querySelectorAll('.music-toggle').forEach((button) => {
        button.setAttribute('aria-pressed', String(isOn()));
        button.setAttribute('aria-label', isOn() ? 'Turn music off' : 'Turn music on');
    });
}

function getAudio() {
    if (audio) return audio;
    audio = new Audio();
    audio.preload = 'auto';
    audio.volume = MUSIC.volume;
    audio.addEventListener('ended', () => {
        failures = 0;
        playTrack(trackIndex + 1);
    });
    audio.addEventListener('error', onTrackError);
    return audio;
}

function onTrackError() {
    failures += 1;
    if (failures >= MUSIC.tracks.length) {
        console.warn('Music: none of the tracks in config.js could be loaded.');
        return;
    }
    playTrack(trackIndex + 1);
}

function playTrack(index) {
    trackIndex = (index + MUSIC.tracks.length) % MUSIC.tracks.length;
    getAudio().src = MUSIC.tracks[trackIndex];
    return start();
}

async function start() {
    const player = getAudio();
    if (!player.src) player.src = MUSIC.tracks[trackIndex];
    try {
        await player.play();
        blocked = false;
        stopWaitingForGesture();
    } catch (err) {
        if (err && err.name === 'NotAllowedError') {
            blocked = true;
            waitForGesture();
        } else if (!err || err.name !== 'AbortError') {
            console.warn('Music could not start:', err);
        }
    }
    refreshToggles();
}

function onFirstGesture(evt) {

    if (evt.target instanceof Element && evt.target.closest('.music-toggle')) return;
    stopWaitingForGesture();
    if (wanted) start();
}

function waitForGesture() {
    if (waitingForGesture) return;
    waitingForGesture = true;
    document.addEventListener('click', onFirstGesture, true);
    document.addEventListener('keydown', onFirstGesture, true);
}

function stopWaitingForGesture() {
    waitingForGesture = false;
    document.removeEventListener('click', onFirstGesture, true);
    document.removeEventListener('keydown', onFirstGesture, true);
}

function onToggleClick() {
    if (blocked) {

        wanted = true;
        writePreference(true);
        start();
        return;
    }

    wanted = !wanted;
    writePreference(wanted);
    if (wanted) {
        start();
    } else {
        blocked = false;
        stopWaitingForGesture();
        if (audio) audio.pause();
    }
    refreshToggles();
}

export function initMusic() {
    wanted = readPreference();
    blocked = wanted;
    document.querySelectorAll('.music-toggle').forEach((button) => {
        button.addEventListener('click', onToggleClick);
    });
    refreshToggles();

    if (wanted) {
        trackIndex = Math.floor(Math.random() * MUSIC.tracks.length);
        playTrack(trackIndex);
    }
}
