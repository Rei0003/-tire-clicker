(function () {
    var stored = null;
    try { stored = localStorage.getItem('tire-clicker-theme'); } catch (e) { }

    var theme = stored;
    if (!theme) {
        theme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches)
            ? 'light' : 'dark';
    }
    if (theme === 'light') document.documentElement.setAttribute('data-theme', 'light');
})();
