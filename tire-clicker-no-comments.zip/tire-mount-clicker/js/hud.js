import { state, tiresPerSecond, globalMultiplier } from './state.js';
import { getBonusMultiplier } from './bonus.js';
import { formatNumber, formatRate } from './format.js';
import { el } from './dom.js';

export function refreshTopStats() {
    el.tiresStat.textContent = formatNumber(state.tires) + ' tires';

    const mult = globalMultiplier() * getBonusMultiplier();
    el.rateStat.textContent = formatRate(tiresPerSecond() * mult) + ' tires/sec';
    el.multStat.hidden = mult === 1;
    el.multStat.textContent = '\u00D7' + Number(mult.toFixed(2)) + ' income';
}
