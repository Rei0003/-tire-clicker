let ctx = null;

function getCtx() {
    if (!ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
}

function tone(freq, duration, { type = 'sine', endFreq = freq, gain = 0.18, delay = 0 } = {}) {
    const audioCtx = getCtx();
    if (!audioCtx) return;

    const t0 = audioCtx.currentTime + delay;
    const osc = audioCtx.createOscillator();
    const vol = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    osc.frequency.exponentialRampToValueAtTime(Math.max(endFreq, 1), t0 + duration);
    vol.gain.setValueAtTime(gain, t0);
    vol.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(vol).connect(audioCtx.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.02);
}

export function playClick() {
    const wobble = 0.94 + Math.random() * 0.12;
    tone(220 * wobble, 0.09, { type: 'square', endFreq: 90 * wobble, gain: 0.12 });
}

export function playPurchase() {
    tone(660, 0.09, { type: 'triangle', endFreq: 660, gain: 0.16 });
    tone(990, 0.14, { type: 'triangle', endFreq: 990, gain: 0.14, delay: 0.06 });
}

export function playTierUp() {
    [523, 659, 784, 1047].forEach((freq, i) => {
        tone(freq, 0.16, { type: 'sawtooth', endFreq: freq, gain: 0.12, delay: i * 0.07 });
    });
}

export function playBonus() {
    tone(220, 0.35, { type: 'sawtooth', endFreq: 880, gain: 0.16 });
}
