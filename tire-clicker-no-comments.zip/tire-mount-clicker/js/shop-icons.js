const O = 'stroke="#1B1D22" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"';
const svg = (body) => `<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false">${body}</svg>`;

const tire = (cx, cy, r) =>
    `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#2A2C31" ${O}/><circle cx="${cx}" cy="${cy}" r="${r * 0.5}" fill="#B9BEC6" ${O}/>`;

export const SHOP_ICONS = {

    rookie: svg(`
        <path d="M10 44 C10 34 16 30 24 30 C32 30 38 34 38 44 Z" fill="#3E7CC2" ${O}/>
        <circle cx="24" cy="20" r="9" fill="#F2C9A0" ${O}/>
        <path d="M14 18 C14 9 34 9 34 18 Z" fill="#E4574B" ${O}/>
        <path d="M31 17 L40 18" ${O}/>
        <rect x="20" y="34" width="8" height="5" rx="1" fill="#F5C024" ${O}/>`),
    wrenchStation: svg(`
        <rect x="6" y="14" width="26" height="14" rx="4" fill="#9AA3AE" ${O}/>
        <rect x="32" y="17" width="10" height="8" rx="1" fill="#6B7280" ${O}/>
        <path d="M12 28 L10 42 L20 42 L22 28 Z" fill="#E4574B" ${O}/>
        <path d="M22 30 L26 34" ${O}/>
        <circle cx="14" cy="21" r="2.5" fill="#F5C024" ${O}/>`),
    balancer: svg(`
        <rect x="6" y="32" width="36" height="12" rx="2" fill="#6B7280" ${O}/>
        <rect x="21" y="24" width="6" height="9" fill="#9AA3AE" ${O}/>
        ${tire(24, 17, 12)}
        <circle cx="36" cy="38" r="2.5" fill="#43D17A" ${O}/>`),
    secondBay: svg(`
        <path d="M5 20 L24 7 L43 20 L43 43 L5 43 Z" fill="#E8DCC4" ${O}/>
        <rect x="11" y="23" width="26" height="20" fill="#9AA3AE" ${O}/>
        <path d="M11 28 H37 M11 33 H37 M11 38 H37" ${O}/>
        <circle cx="24" cy="15" r="3" fill="#F5C024" ${O}/>`),
    pitCrew: svg(`
        <path d="M4 44 C4 36 8 32 15 32 C22 32 26 36 26 44 Z" fill="#E4574B" ${O}/>
        <path d="M22 44 C22 36 26 32 33 32 C40 32 44 36 44 44 Z" fill="#E4574B" ${O}/>
        <circle cx="15" cy="21" r="9" fill="#F5F5F5" ${O}/><path d="M8 21 H22 V25 H8 Z" fill="#2A2C31" ${O}/>
        <circle cx="33" cy="21" r="9" fill="#F5F5F5" ${O}/><path d="M26 21 H40 V25 H26 Z" fill="#2A2C31" ${O}/>`),
    hydraulicLine: svg(`
        <rect x="6" y="10" width="6" height="34" fill="#F5C024" ${O}/>
        <rect x="36" y="10" width="6" height="34" fill="#F5C024" ${O}/>
        <rect x="9" y="26" width="30" height="5" fill="#6B7280" ${O}/>
        <path d="M13 26 L16 18 H32 L35 26 Z" fill="#3E7CC2" ${O}/>
        <path d="M24 34 V42 M20 38 L24 34 L28 38" ${O}/>`),
    deliveryFleet: svg(`
        <rect x="4" y="12" width="26" height="22" rx="2" fill="#F5F5F5" ${O}/>
        <path d="M30 18 H38 L44 26 V34 H30 Z" fill="#3E7CC2" ${O}/>
        <path d="M33 21 H37 L40 26 H33 Z" fill="#CFE8F7" ${O}/>
        ${tire(13, 36, 5)} ${tire(36, 36, 5)}`),
    warehouse: svg(`
        <path d="M3 18 L24 8 L45 18 V43 H3 Z" fill="#C99A6B" ${O}/>
        <rect x="14" y="26" width="20" height="17" fill="#9AA3AE" ${O}/>
        <path d="M14 31 H34 M14 36 H34" ${O}/>
        ${tire(9, 38, 4)} ${tire(39, 38, 4)}`),
    franchise: svg(`
        <rect x="8" y="20" width="32" height="23" fill="#F5F5F5" ${O}/>
        <path d="M5 20 L10 11 H38 L43 20 Z" fill="#E4574B" ${O}/>
        <rect x="19" y="30" width="10" height="13" fill="#3E7CC2" ${O}/>
        <path d="M24 11 V3 L33 6 L24 9" fill="#F5C024" ${O}/>`),

    boots: svg(`
        <path d="M14 6 H27 V28 L40 31 C44 32 44 42 40 42 H9 C8 42 8 36 10 32 Z" fill="#8A5A36" ${O}/>
        <path d="M30 29 L40 31 C44 32 44 42 40 42 H30 Z" fill="#B9BEC6" ${O}/>
        <path d="M8 38 H44" ${O}/>`),
    pneumatic: svg(`
        <path d="M6 38 C2 30 12 26 18 32 C24 38 34 34 30 26" fill="none" stroke="#1B1D22" stroke-width="7" stroke-linecap="round"/>
        <path d="M6 38 C2 30 12 26 18 32 C24 38 34 34 30 26" fill="none" stroke="#43A5E0" stroke-width="3" stroke-linecap="round"/>
        <rect x="24" y="8" width="18" height="12" rx="3" fill="#9AA3AE" ${O}/>
        <path d="M28 20 L27 28 H33 L34 20 Z" fill="#E4574B" ${O}/>`),
    jack: svg(`
        <rect x="4" y="34" width="34" height="8" rx="3" fill="#E4574B" ${O}/>
        <path d="M12 34 L28 16 L32 20 L20 34 Z" fill="#E4574B" ${O}/>
        <rect x="24" y="10" width="14" height="6" rx="2" fill="#6B7280" ${O}/>
        <path d="M38 38 L46 30" ${O}/>
        ${tire(10, 42, 3)} ${tire(32, 42, 3)}`),
    roboticArm: svg(`
        <rect x="6" y="38" width="18" height="6" rx="2" fill="#6B7280" ${O}/>
        <path d="M15 38 L20 22" stroke="#1B1D22" stroke-width="8" stroke-linecap="round"/>
        <path d="M15 38 L20 22" stroke="#F5A623" stroke-width="4" stroke-linecap="round"/>
        <path d="M20 22 L36 14" stroke="#1B1D22" stroke-width="8" stroke-linecap="round"/>
        <path d="M20 22 L36 14" stroke="#F5A623" stroke-width="4" stroke-linecap="round"/>
        <circle cx="20" cy="22" r="4" fill="#9AA3AE" ${O}/>
        <path d="M36 14 L42 8 M36 14 L44 16" ${O}/>`),
    autoBay: svg(`
        <path d="M24 4 L28 9 L34 7 L35 13 L41 14 L39 20 L44 24 L39 28 L41 34 L35 35 L34 41 L28 39 L24 44 L20 39 L14 41 L13 35 L7 34 L9 28 L4 24 L9 20 L7 14 L13 13 L14 7 L20 9 Z" fill="#9AA3AE" ${O}/>
        ${tire(24, 24, 11)}`),
    nitrogen: svg(`
        <rect x="14" y="12" width="20" height="32" rx="8" fill="#43B06A" ${O}/>
        <rect x="20" y="5" width="8" height="7" fill="#9AA3AE" ${O}/>
        <path d="M17 6 H31" ${O}/>
        <text x="24" y="33" text-anchor="middle" font-family="Roboto, Arial, sans-serif" font-weight="900" font-size="12" fill="#FFFFFF">N2</text>`),
    laserAlign: svg(`
        ${tire(16, 24, 12)}
        <rect x="32" y="16" width="12" height="16" rx="2" fill="#6B7280" ${O}/>
        <path d="M32 24 H22" stroke="#E4574B" stroke-width="3" stroke-linecap="round"/>
        <circle cx="16" cy="24" r="3" fill="#E4574B"/>`),
    titanLift: svg(`
        <rect x="4" y="40" width="40" height="4" fill="#6B7280" ${O}/>
        <rect x="10" y="14" width="28" height="6" fill="#F5C024" ${O}/>
        <path d="M14 20 L34 40 M34 20 L14 40" stroke="#1B1D22" stroke-width="5" stroke-linecap="round"/>
        <path d="M14 20 L34 40 M34 20 L14 40" stroke="#9AA3AE" stroke-width="2" stroke-linecap="round"/>
        <path d="M24 12 V3 M19 7 L24 2 L29 7" ${O}/>`),
    aiAssist: svg(`
        <rect x="11" y="11" width="26" height="26" rx="4" fill="#3E4452" ${O}/>
        <rect x="17" y="17" width="14" height="14" rx="2" fill="#2BE0F5" ${O}/>
        <path d="M17 6 V11 M24 6 V11 M31 6 V11 M17 37 V42 M24 37 V42 M31 37 V42 M6 17 H11 M6 24 H11 M6 31 H11 M37 17 H42 M37 24 H42 M37 31 H42" ${O}/>`),
    quantumRig: svg(`
        <ellipse cx="24" cy="24" rx="19" ry="7" fill="none" stroke="#9B7BFF" stroke-width="3"/>
        <ellipse cx="24" cy="24" rx="19" ry="7" fill="none" stroke="#9B7BFF" stroke-width="3" transform="rotate(60 24 24)"/>
        <ellipse cx="24" cy="24" rx="19" ry="7" fill="none" stroke="#9B7BFF" stroke-width="3" transform="rotate(-60 24 24)"/>
        <circle cx="24" cy="24" r="6" fill="#F5C024" ${O}/>`),

    localSponsor: medal('#C98B4B', '#E0A86A'),
    regionalSponsor: medal('#9AA3AE', '#D4D8DD'),
    nationalSponsor: medal('#D9A400', '#F5C024'),
    tireBrandDeal: svg(`
        <path d="M14 30 L10 46 L18 42 L22 46 L24 32 Z" fill="#E4574B" ${O}/>
        <path d="M34 30 L38 46 L30 42 L26 46 L24 32 Z" fill="#3E7CC2" ${O}/>
        ${tire(24, 20, 16)}
        <path d="M24 13 L26 18 L31 18 L27 21 L28 26 L24 23 L20 26 L21 21 L17 18 L22 18 Z" fill="#F5C024" ${O}/>`),
    globalDeal: svg(`
        <circle cx="24" cy="24" r="19" fill="#43A5E0" ${O}/>
        <path d="M13 12 C18 14 16 20 21 21 C25 22 22 28 26 30 C30 32 28 38 24 43" fill="none" ${O}/>
        <path d="M29 7 C30 12 35 12 36 17 C37 21 42 20 43 23" fill="none" ${O}/>
        <path d="M11 20 C14 22 12 26 16 28 C19 30 17 33 14 35" fill="#6FBF5A" ${O}/>
        <path d="M30 26 C33 24 37 27 36 31 C35 35 30 34 30 30 Z" fill="#6FBF5A" ${O}/>`)
};

function medal(dark, light) {
    return svg(`
        <path d="M15 4 L21 20 L27 20 L21 4 Z" fill="#E4574B" ${O}/>
        <path d="M33 4 L27 20 L21 20 L27 4 Z" fill="#3E7CC2" ${O}/>
        <circle cx="24" cy="30" r="14" fill="${dark}" ${O}/>
        <circle cx="24" cy="30" r="9" fill="${light}" ${O}/>
        <path d="M24 24 L25.8 28 L30 28.3 L26.8 31 L27.8 35 L24 32.8 L20.2 35 L21.2 31 L18 28.3 L22.2 28 Z" fill="${dark}"/>`);
}

export const TAB_ICONS = {
    generators: SHOP_ICONS.rookie,
    upgrades: SHOP_ICONS.jack,
    multipliers: SHOP_ICONS.nationalSponsor
};
