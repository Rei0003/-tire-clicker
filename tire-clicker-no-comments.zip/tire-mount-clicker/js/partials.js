const cache = new Map();

function fetchPartial(url) {
    if (!cache.has(url)) {
        cache.set(url, fetch(url).then((res) => {
            if (!res.ok) throw new Error('Could not load ' + url + ' (' + res.status + ')');
            return res.text();
        }));
    }
    return cache.get(url);
}

export async function loadPartials(root = document) {
    for (let depth = 0; depth < 8; depth++) {
        const slots = Array.from(root.querySelectorAll('[data-include]'));
        if (slots.length === 0) return;

        const texts = await Promise.all(slots.map((slot) => fetchPartial(slot.dataset.include)));
        slots.forEach((slot, i) => {
            const template = document.createElement('template');
            template.innerHTML = texts[i];
            slot.replaceWith(template.content);
        });
    }
    throw new Error('Partials are nested too deeply (does one include itself?).');
}
