import { TICK_MS, SHOP_REFRESH_MS, AUTOSAVE_MS } from './config.js';
import { state, resetState, applyServerState, clickPower, tiresPerSecond, globalMultiplier } from './state.js';
import { apiGet, apiPost } from './api.js';
import { el } from './dom.js';
import { refreshTopStats } from './hud.js';
import { refreshVehicleTier, mountTires, spawnClickPop } from './vehicle.js';
import { renderShop } from './shop.js';
import { queueSave, flushSave, beaconSave } from './save.js';
import { initBonus, stopBonus, getBonusMultiplier } from './bonus.js';
import { playClick } from './sfx.js';

let tickTimer = null;
let shopTimer = null;
let saveTimer = null;

function tick() {
    const perSecond = tiresPerSecond();
    if (perSecond > 0) {
        mountTires(perSecond * TICK_MS / 1000 * globalMultiplier() * getBonusMultiplier());
    }
    refreshTopStats();
}

function stopGameLoops() {
    clearInterval(tickTimer);
    clearInterval(shopTimer);
    clearInterval(saveTimer);
    stopBonus();
}

function startGameLoops() {
    stopGameLoops();
    tickTimer = setInterval(tick, TICK_MS);
    shopTimer = setInterval(renderShop, SHOP_REFRESH_MS);
    saveTimer = setInterval(queueSave, AUTOSAVE_MS);
    initBonus();
}

export function enterGame(username) {
    el.screenAuth.classList.add('is-hidden');
    el.screenGame.classList.remove('is-hidden');
    el.topbarUsername.textContent = username || '';

    apiGet('api/load.php').then((data) => {
        resetState();
        if (data.ok && data.state) {
            applyServerState(data.state);
        }
        refreshTopStats();
        refreshVehicleTier();
        renderShop();
        startGameLoops();
    });
}

export function initTireButton() {
    el.tireButton.addEventListener('click', (evt) => {
        const amount = clickPower() * globalMultiplier() * getBonusMultiplier();
        mountTires(amount);
        playClick();

        const rect = el.tireButton.getBoundingClientRect();
        spawnClickPop(
            evt.clientX || (rect.left + rect.width / 2),
            evt.clientY || rect.top,
            amount
        );
        queueSave();
    });
}

export function initLogout(onSignedOut) {
    el.logoutButton.addEventListener('click', () => {
        stopGameLoops();
        flushSave().then(() => apiPost('api/logout.php', {})).then(() => {
            resetState();
            onSignedOut();
        });
    });
}

export function initSaveOnExit() {
    const saveIfPlaying = () => {
        if (!el.screenGame.classList.contains('is-hidden')) beaconSave();
    };
    window.addEventListener('beforeunload', saveIfPlaying);
    window.addEventListener('pagehide', saveIfPlaying);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') saveIfPlaying();
    });
}
