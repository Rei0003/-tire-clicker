export const GENERATORS = [
    { id: 'rookie', name: 'Rookie Mechanic', baseCost: 15, rate: 1 },
    { id: 'wrenchStation', name: 'Impact Wrench Station', baseCost: 100, rate: 5 },
    { id: 'balancer', name: 'Tire Balancer Rig', baseCost: 600, rate: 20 },
    { id: 'secondBay', name: 'Another Bay', baseCost: 4000, rate: 80 },
    { id: 'pitCrew', name: 'Pit Crew Team', baseCost: 20000, rate: 300 },
    { id: 'hydraulicLine', name: 'Hydraulic Lift Line', baseCost: 100000, rate: 1000 },
    { id: 'deliveryFleet', name: 'Delivery Fleet', baseCost: 500000, rate: 4000 },
    { id: 'warehouse', name: 'Regional Warehouse', baseCost: 2500000, rate: 15000 },
    { id: 'franchise', name: 'National Franchise', baseCost: 12000000, rate: 60000 }
];

export const CLICK_UPGRADES = [
    { id: 'boots', name: 'Steel-Toe Boots', cost: 50, add: 1 },
    { id: 'pneumatic', name: 'Pneumatic Wrench', cost: 500, add: 4 },
    { id: 'jack', name: 'Hydraulic Jack', cost: 5000, add: 10 },
    { id: 'roboticArm', name: 'Robotic Torque Arm', cost: 50000, add: 50 },
    { id: 'autoBay', name: 'Full Auto Bay', cost: 500000, add: 250 },
    { id: 'nitrogen', name: 'Nitrogen Tire Filler', cost: 2000000, add: 1000 },
    { id: 'laserAlign', name: 'Laser Wheel Aligner', cost: 10000000, add: 5000 },
    { id: 'titanLift', name: 'Titan Lift System', cost: 50000000, add: 25000 },
    { id: 'aiAssist', name: 'AI Tire Assistant', cost: 250000000, add: 100000 },
    { id: 'quantumRig', name: 'Quantum Torque Rig', cost: 1000000000, add: 500000 }
];

export const MULTIPLIERS = [
    { id: 'localSponsor', name: 'Local Sponsor', cost: 2000, mult: 1.25 },
    { id: 'regionalSponsor', name: 'Regional Sponsor', cost: 25000, mult: 1.5 },
    { id: 'nationalSponsor', name: 'National Sponsor', cost: 300000, mult: 2 },
    { id: 'tireBrandDeal', name: 'Tire Brand Deal', cost: 4000000, mult: 2.5 },
    { id: 'globalDeal', name: 'Global Circuit Deal', cost: 60000000, mult: 3 }
];

export const BONUS = {

    minGapMs: 60000,
    averageWaitMs: 150000,
    visibleMs: 12000,
    durationMs: 20000,
    multiplier: 2
};

export const TIRE_TIER_NAMES = [
    'Street Tire', 'Street Wheel', 'Sport Wheel', 'Off-Road Wheel', 'Racing Wheel', 'Rally Wheel',
    'Supercar Wheel', 'Drag Slick', 'Monster Tire', 'Hypercar Wheel', 'Record Wheel'
];

export const COST_GROWTH = 1.15;
export const WHEELS_PER_CAR = 2;

export const TICK_MS = 100;
export const SHOP_REFRESH_MS = 500;
export const AUTOSAVE_MS = 6000;
export const SAVE_DEBOUNCE_MS = 800;
export const PURCHASE_SAVE_DEBOUNCE_MS = 150;
export const CAR_EXIT_MS = 500;
export const CAR_ENTER_MS = 350;
export const CAR_MIN_STAY_MS = 1200;

export const CAR_PAINTS = [
    { name: 'Factory', factory: true },
    { name: 'Red', hue: 358, sat: 0.72, light: 0.45 },
    { name: 'Orange', hue: 24, sat: 0.85, light: 0.52 },
    { name: 'Yellow', hue: 47, sat: 0.88, light: 0.55 },
    { name: 'Green', hue: 128, sat: 0.55, light: 0.40 },
    { name: 'Teal', hue: 176, sat: 0.55, light: 0.38 },
    { name: 'Blue', hue: 214, sat: 0.62, light: 0.44 },
    { name: 'Purple', hue: 272, sat: 0.48, light: 0.44 },
    { name: 'Pink', hue: 328, sat: 0.68, light: 0.60 },
    { name: 'Silver', sat: 0.05, light: 0.70 },
    { name: 'Black', sat: 0.04, light: 0.15 },
    { name: 'White', sat: 0.03, light: 0.88 }
];

export const THEME_KEY = 'tire-clicker-theme';

export const MUSIC = {
    storageKey: 'tire-clicker-music',
    volume: 0.3,
    tracks: [
        'assets/music/background-music.mp3',
        'assets/music/driving-beat.mp3',
        'assets/music/rock-instrumental.mp3'
    ]
};
