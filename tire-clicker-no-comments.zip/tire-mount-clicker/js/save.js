import { SAVE_DEBOUNCE_MS, PURCHASE_SAVE_DEBOUNCE_MS } from './config.js';
import { serializeState } from './state.js';
import { session } from './session.js';
import { apiPost } from './api.js';
import { el } from './dom.js';

let saveTimer = null;
let pending = false;
let inFlight = null;

export function queueSave() {
    queue(SAVE_DEBOUNCE_MS);
}

export function queueSaveSoon() {
    queue(PURCHASE_SAVE_DEBOUNCE_MS);
}

function queue(delay) {
    pending = true;
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(persist, delay);
}

export function persist() {
    if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
    pending = false;

    el.saveIndicator.textContent = 'saving...';
    el.saveIndicator.classList.add('is-saving');

    inFlight = apiPost('api/save.php', {
        csrf_token: session.csrfToken,
        state: serializeState()
    }).then((data) => {
        el.saveIndicator.classList.remove('is-saving');
        el.saveIndicator.textContent = data.ok ? 'saved' : 'save failed';
    }).catch(() => {
        el.saveIndicator.classList.remove('is-saving');
        el.saveIndicator.textContent = 'offline';
    }).finally(() => { inFlight = null; });

    return inFlight;
}

export function flushSave() {
    if (pending) return persist();
    return inFlight || Promise.resolve();
}

export function beaconSave() {
    if (!pending && !inFlight) return;
    if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
    pending = false;

    if (!navigator.sendBeacon) { persist(); return; }
    const blob = new Blob([JSON.stringify({
        csrf_token: session.csrfToken,
        state: serializeState()
    })], { type: 'application/json' });
    navigator.sendBeacon('api/save.php', blob);
}
