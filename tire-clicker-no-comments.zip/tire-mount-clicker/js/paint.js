function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2;
    if (max === min) return [0, 0, l];
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    let h;
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    return [(h * 60 + 360) % 360, s, l];
}

function hslToRgb(h, s, l) {
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60) [r, g, b] = [c, x, 0];
    else if (h < 120) [r, g, b] = [x, c, 0];
    else if (h < 180) [r, g, b] = [0, c, x];
    else if (h < 240) [r, g, b] = [0, x, c];
    else if (h < 300) [r, g, b] = [x, 0, c];
    else [r, g, b] = [c, 0, x];
    return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
}

const clamp01 = (v) => Math.min(1, Math.max(0, v));

function paintWeight(h, s, l, car) {
    let d = Math.abs(h - car.hue);
    d = Math.min(d, 360 - d);
    const hueW = clamp01((car.range + 8 - d) / 8);
    const satW = clamp01((s - 0.12) / 0.14);
    const lightW = clamp01((l - 0.06) / 0.06) * clamp01((0.94 - l) / 0.06);
    return hueW * satW * lightW;
}

export function repaintPixels(data, width, height, car, paint) {
    const keep = car.keep.map(([x0, y0, x1, y1]) => [x0 * width, y0 * height, x1 * width, y1 * height]);
    const n = width * height;
    const hsl = new Float32Array(n * 3);
    const weight = new Float32Array(n);
    let sumW = 0, sumS = 0, sumL = 0;

    for (let p = 0; p < n; p++) {
        const i = p * 4;
        if (data[i + 3] === 0) continue;
        const x = p % width, y = (p - x) / width;
        if (keep.some(([x0, y0, x1, y1]) => x >= x0 && x < x1 && y >= y0 && y < y1)) continue;
        const [h, s, l] = rgbToHsl(data[i], data[i + 1], data[i + 2]);
        const w = paintWeight(h, s, l, car);
        if (w === 0) continue;
        hsl[p * 3] = h; hsl[p * 3 + 1] = s; hsl[p * 3 + 2] = l;
        weight[p] = w;
        sumW += w; sumS += s * w; sumL += l * w;
    }
    if (sumW === 0) return;
    const meanS = sumS / sumW, meanL = sumL / sumW;

    for (let p = 0; p < n; p++) {
        const w = weight[p];
        if (w === 0) continue;
        const h = hsl[p * 3], s = hsl[p * 3 + 1], l = hsl[p * 3 + 2];
        const nh = paint.hue ?? h;
        const ns = paint.sat === undefined ? s : clamp01(s - meanS + paint.sat);
        const nl = paint.light === undefined ? l : clamp01(l - meanL + paint.light);
        const [r, g, b] = hslToRgb(nh, ns, nl);
        const i = p * 4;
        data[i] = data[i] + (r - data[i]) * w;
        data[i + 1] = data[i + 1] + (g - data[i + 1]) * w;
        data[i + 2] = data[i + 2] + (b - data[i + 2]) * w;
    }
}

export function readCarPaint(face) {
    const keep = (face.dataset.keep || '')
        .split(';').filter(Boolean)
        .map((box) => box.split(',').map(Number));
    return {
        hue: Number(face.dataset.paintHue),
        range: Number(face.dataset.paintRange || 14),
        keep
    };
}

export function looksDifferent(paint, car) {
    if (paint.factory) return true;
    if (paint.hue === undefined) return true;
    let d = Math.abs(paint.hue - car.hue);
    d = Math.min(d, 360 - d);
    return d > 30;
}

const originals = new Map();
const painted = new Map();
const MAX_CACHED = 30;

function loadPixels(url) {
    if (!originals.has(url)) {
        originals.set(url, new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;
                const ctx = canvas.getContext('2d');
                if (!ctx) { reject(new Error('no canvas')); return; }
                ctx.drawImage(img, 0, 0);
                resolve(ctx.getImageData(0, 0, canvas.width, canvas.height));
            };
            img.onerror = () => reject(new Error('could not load ' + url));
            img.src = url;
        }));
    }
    return originals.get(url);
}

let canvasOk = null;
function canvasSupported() {
    if (canvasOk === null) {
        try { canvasOk = !!document.createElement('canvas').getContext('2d'); } catch (e) { canvasOk = false; }
    }
    return canvasOk;
}

export async function paintedUrl(url, car, paint) {
    if (paint.factory) return url;
    if (!canvasSupported()) return null;
    const key = url + '|' + paint.name;
    if (painted.has(key)) return painted.get(key);

    try {
        const source = await loadPixels(url);
        const copy = new ImageData(new Uint8ClampedArray(source.data), source.width, source.height);
        repaintPixels(copy.data, copy.width, copy.height, car, paint);

        const canvas = document.createElement('canvas');
        canvas.width = copy.width;
        canvas.height = copy.height;
        canvas.getContext('2d').putImageData(copy, 0, 0);
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
        if (!blob) return null;

        const out = URL.createObjectURL(blob);
        painted.set(key, out);
        if (painted.size > MAX_CACHED) {
            const [oldKey, oldUrl] = painted.entries().next().value;
            painted.delete(oldKey);
            URL.revokeObjectURL(oldUrl);
        }
        return out;
    } catch (err) {
        return null;
    }
}
