import { GENERATORS, CLICK_UPGRADES, MULTIPLIERS, COST_GROWTH, WHEELS_PER_CAR } from './config.js';

function freshState() {
    return {
        tires: 0,
        totalTires: 0,
        generators: {},
        clickUpgrades: [],
        multipliers: [],
        carsCompleted: 0,
        wheelsOnCurrentCar: 0
    };
}

export const state = freshState();

export function resetState() {
    Object.assign(state, freshState());
}

export function applyServerState(saved) {
    saved = saved || {};
    state.tires = Number(saved.tires) || 0;
    state.totalTires = Number(saved.totalTires) || 0;

    state.generators = (saved.generators && typeof saved.generators === 'object' && !Array.isArray(saved.generators))
        ? saved.generators : {};
    state.clickUpgrades = Array.isArray(saved.clickUpgrades) ? saved.clickUpgrades : [];
    state.multipliers = Array.isArray(saved.multipliers) ? saved.multipliers : [];
    state.carsCompleted = Number(saved.carsCompleted) || 0;
    state.wheelsOnCurrentCar = Math.max(0, Math.min(WHEELS_PER_CAR, Number(saved.wheelsOnCurrentCar) || 0));
}

export function serializeState() {
    return {
        tires: state.tires,
        totalTires: state.totalTires,
        clickPower: clickPower(),
        generators: state.generators,
        clickUpgrades: state.clickUpgrades,
        multipliers: state.multipliers,
        carsCompleted: state.carsCompleted,
        wheelsOnCurrentCar: state.wheelsOnCurrentCar
    };
}

export function clickPower() {
    let power = 1;
    for (const upgrade of CLICK_UPGRADES) {
        if (state.clickUpgrades.includes(upgrade.id)) power += upgrade.add;
    }
    return power;
}

export function tiresPerSecond() {
    let rate = 0;
    for (const gen of GENERATORS) {
        rate += (state.generators[gen.id] || 0) * gen.rate;
    }
    return rate;
}

export function generatorCost(gen) {
    const owned = state.generators[gen.id] || 0;
    return Math.ceil(gen.baseCost * Math.pow(COST_GROWTH, owned));
}

export function globalMultiplier() {
    let mult = 1;
    for (const m of MULTIPLIERS) {
        if (state.multipliers.includes(m.id)) mult *= m.mult;
    }
    return mult;
}
