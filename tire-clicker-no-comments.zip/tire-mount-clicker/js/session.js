export const session = { csrfToken: null };
