import { GENERATORS, CLICK_UPGRADES, MULTIPLIERS, TIRE_TIER_NAMES } from './config.js';
import { state, generatorCost } from './state.js';
import { formatNumber } from './format.js';
import { el } from './dom.js';
import { refreshTopStats } from './hud.js';
import { refreshVehicleTier } from './vehicle.js';
import { queueSaveSoon } from './save.js';
import { playPurchase } from './sfx.js';
import { SHOP_ICONS, TAB_ICONS } from './shop-icons.js';

function buyGenerator(gen) {
    const cost = generatorCost(gen);
    if (state.tires < cost) return;
    state.tires -= cost;
    state.generators[gen.id] = (state.generators[gen.id] || 0) + 1;
    afterPurchase();
}

function buyClickUpgrade(upgrade) {
    if (state.clickUpgrades.includes(upgrade.id) || state.tires < upgrade.cost) return;
    state.tires -= upgrade.cost;
    state.clickUpgrades.push(upgrade.id);
    refreshVehicleTier();
    afterPurchase();
}

function buyMultiplier(mult) {
    if (state.multipliers.includes(mult.id) || state.tires < mult.cost) return;
    state.tires -= mult.cost;
    state.multipliers.push(mult.id);
    afterPurchase();
}

function afterPurchase() {
    playPurchase();
    refreshTopStats();
    renderShop();
    queueSaveSoon();
}

function generatorItems() {
    return GENERATORS.map((gen) => ({
        id: gen.id,
        name: gen.name,
        effect: '+' + formatNumber(gen.rate) + ' tires/sec each',
        count: state.generators[gen.id] || 0,
        cost: generatorCost(gen),
        onBuy: () => buyGenerator(gen)
    }));
}

function upgradeItems() {
    return CLICK_UPGRADES
        .map((upgrade, i) => ({ upgrade, unlocks: TIRE_TIER_NAMES[i + 1] }))
        .filter(({ upgrade }) => !state.clickUpgrades.includes(upgrade.id))
        .map(({ upgrade, unlocks }) => ({
            id: upgrade.id,
            name: upgrade.name,
            effect: '+' + upgrade.add.toLocaleString() + ' per click',
            chip: unlocks ? 'Unlocks ' + unlocks : '',
            cost: upgrade.cost,
            onBuy: () => buyClickUpgrade(upgrade)
        }));
}

function multiplierItems() {
    return MULTIPLIERS
        .filter((m) => !state.multipliers.includes(m.id))
        .map((m) => ({
            id: m.id,
            name: m.name,
            effect: '\u00D7' + m.mult + ' all income',
            chip: 'stacks with the others',
            cost: m.cost,
            onBuy: () => buyMultiplier(m)
        }));
}

function makeCard(item, category) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'shop-card cat-' + category;
    card.innerHTML = `
        <span class="shop-card-icon">${SHOP_ICONS[item.id] || ''}<span class="shop-card-count"></span></span>
        <span class="shop-card-body">
            <span class="shop-card-name"></span>
            <span class="shop-card-effect"></span>
            <span class="shop-card-chip"></span>
        </span>
        <span class="shop-card-price"><span class="shop-card-cost"></span><small>tires</small></span>
        <span class="shop-card-progress" aria-hidden="true"><span></span></span>`;
    card.querySelector('.shop-card-name').textContent = item.name;
    card.addEventListener('click', () => card.buy && card.buy());
    return card;
}

function updateCard(card, item) {
    const affordable = state.tires >= item.cost;
    card.buy = item.onBuy;
    card.disabled = !affordable;
    card.classList.toggle('can-afford', affordable);

    card.querySelector('.shop-card-effect').textContent = item.effect;
    const chip = card.querySelector('.shop-card-chip');
    chip.textContent = item.chip || '';
    chip.hidden = !item.chip;
    const count = card.querySelector('.shop-card-count');
    count.textContent = '\u00D7' + (item.count || 0);
    count.hidden = !item.count;
    card.querySelector('.shop-card-cost').textContent = formatNumber(item.cost);
    card.querySelector('.shop-card-progress span').style.transform =
        `scaleX(${Math.min(1, state.tires / item.cost)})`;
    card.setAttribute('aria-label',
        `${item.name}: ${item.effect}. Costs ${formatNumber(item.cost)} tires` +
        (affordable ? '.' : `, you have ${formatNumber(state.tires)}.`));
}

function syncPanel(panel, category, items, emptyText) {
    const ids = items.map((i) => i.id).join('|');
    if (panel.dataset.ids !== ids) {
        panel.dataset.ids = ids;
        panel.innerHTML = '';
        for (const item of items) {
            const card = makeCard(item, category);
            card.dataset.id = item.id;
            panel.appendChild(card);
        }
        if (!items.length) {
            const done = document.createElement('p');
            done.className = 'shop-empty';
            done.textContent = emptyText;
            panel.appendChild(done);
        }
    }
    const byId = new Map(items.map((i) => [i.id, i]));
    panel.querySelectorAll('.shop-card').forEach((card) => updateCard(card, byId.get(card.dataset.id)));
    return items.some((i) => state.tires >= i.cost);
}

export function renderShop() {
    const canBuy = {
        generators: syncPanel(el.shopGenerators, 'generators', generatorItems(), ''),
        upgrades: syncPanel(el.shopUpgrades, 'upgrades', upgradeItems(),
            'Every garage upgrade is installed. Click power maxed for now.'),
        multipliers: syncPanel(el.shopMultipliers, 'multipliers', multiplierItems(),
            'Every sponsorship deal is signed. Income multiplier maxed for now.')
    };

    el.shopTabs.forEach((tab) => tab.classList.toggle('has-affordable', canBuy[tab.dataset.shopTab]));
}

export function initShopTabs() {
    const panels = {
        generators: el.shopGenerators,
        upgrades: el.shopUpgrades,
        multipliers: el.shopMultipliers
    };
    document.querySelectorAll('[data-tab-icon]').forEach((slot) => {
        slot.innerHTML = TAB_ICONS[slot.dataset.tabIcon] || '';
    });
    el.shopTabs.forEach((tab) => {
        tab.addEventListener('click', () => {
            el.shopTabs.forEach((t) => {
                t.classList.toggle('is-active', t === tab);
                t.setAttribute('aria-selected', String(t === tab));
            });
            Object.entries(panels).forEach(([name, panel]) => {
                panel.classList.toggle('is-hidden', name !== tab.dataset.shopTab);
            });
        });
    });
}
