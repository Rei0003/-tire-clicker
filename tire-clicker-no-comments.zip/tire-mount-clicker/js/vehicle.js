import { TIRE_TIER_NAMES, WHEELS_PER_CAR, CAR_EXIT_MS, CAR_ENTER_MS, CAR_MIN_STAY_MS, CAR_PAINTS } from './config.js';
import { state } from './state.js';
import { el } from './dom.js';
import { formatNumber } from './format.js';
import { refreshTopStats } from './hud.js';
import { playTierUp } from './sfx.js';
import { paintedUrl, readCarPaint, looksDifferent } from './paint.js';

let lastTier = null;
let carBusy = false;
let paintName = 'Factory';
let lastCarTier = null;
let nextPaint = null;

function activeCar() {
    const face = el.carStage.querySelector('.car-face.is-active');
    if (!face) return null;
    const img = face.querySelector('.car-photo');
    if (!img.dataset.original) img.dataset.original = img.getAttribute('src');
    return { face, img };
}

function prepareNextPaint() {
    const car = activeCar();
    if (!car) return null;
    const settings = readCarPaint(car.face);
    const choices = CAR_PAINTS.filter((p) => p.name !== paintName && looksDifferent(p, settings));
    const paint = choices[Math.floor(Math.random() * choices.length)];
    return { ...car, paint, url: paintedUrl(car.img.dataset.original, settings, paint) };
}

async function applyPaint(next) {
    if (!next) return;
    const url = await Promise.race([next.url, new Promise((r) => setTimeout(() => r(null), 1500))]);
    if (!url || !next.face.classList.contains('is-active')) return;
    next.img.src = url;
    try { await next.img.decode(); } catch (e) { }
    paintName = next.paint.name;
}

function carTierFor(tier) {
    let best = null;
    el.carFaces.forEach((face) => {
        const t = Number(face.dataset.carTier);
        if (t <= tier && (best === null || t > best)) best = t;
    });
    return best;
}

export function refreshVehicleTier() {
    const maxTier = TIRE_TIER_NAMES.length - 1;
    const tier = Math.min(state.clickUpgrades.length, maxTier);
    const carTier = carTierFor(tier);

    el.tireFaces.forEach((face) => {
        face.classList.toggle('is-active', Number(face.dataset.tireTier) === tier);
    });
    el.carFaces.forEach((face) => {
        face.classList.toggle('is-active', Number(face.dataset.carTier) === carTier);
    });

    if (carTier !== lastCarTier) {
        const car = activeCar();
        if (car) car.img.src = car.img.dataset.original;
        paintName = 'Factory';
        lastCarTier = carTier;
        nextPaint = prepareNextPaint();
    }
    if (el.tireButtonLabel) {
        el.tireButtonLabel.textContent = TIRE_TIER_NAMES[tier];
    }

    el.carStage.classList.toggle('is-maxed', tier === maxTier);

    if (lastTier !== null && tier > lastTier) {
        playTierUp();
    }
    lastTier = tier;
}

function completeCarIfReady() {
    if (carBusy || state.wheelsOnCurrentCar < WHEELS_PER_CAR) return;

    carBusy = true;
    state.carsCompleted += 1;
    el.carStage.classList.add('is-leaving');
    const next = nextPaint || prepareNextPaint();

    setTimeout(async () => {
        await applyPaint(next);
        nextPaint = prepareNextPaint();
        state.wheelsOnCurrentCar = 0;
        el.carStage.classList.remove('is-leaving');
        el.carStage.classList.add('is-arriving');
        setTimeout(() => el.carStage.classList.remove('is-arriving'), CAR_ENTER_MS);

        setTimeout(() => { carBusy = false; }, CAR_ENTER_MS + CAR_MIN_STAY_MS);
    }, CAR_EXIT_MS);
}

export function mountTires(amount) {
    state.tires += amount;
    state.totalTires += amount;

    if (!carBusy) {
        state.wheelsOnCurrentCar = Math.min(WHEELS_PER_CAR, state.wheelsOnCurrentCar + Math.ceil(amount));
    }
    completeCarIfReady();
    refreshTopStats();
}

export function spawnClickPop(x, y, amount) {
    const pop = document.createElement('div');
    pop.className = 'click-pop';
    pop.textContent = '+' + formatNumber(amount);
    pop.style.left = x + 'px';
    pop.style.top = y + 'px';
    document.body.appendChild(pop);
    setTimeout(() => pop.remove(), 700);
}
