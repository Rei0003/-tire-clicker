import { loadPartials } from './partials.js';
import { collectElements } from './dom.js';
import { session } from './session.js';
import { apiGet } from './api.js';
import { initThemeToggles } from './theme.js';
import { initMusic } from './music.js';
import { initAuthScreen, showAuthScreen, showAuthError, resetAuthForms } from './auth.js';
import { initShopTabs } from './shop.js';
import { enterGame, initTireButton, initLogout, initSaveOnExit } from './game.js';

function checkSession() {
    apiGet('api/session.php').then((data) => {
        session.csrfToken = data.csrf_token;
        if (data.loggedIn) {
            enterGame(data.username);
        } else {
            showAuthScreen();
        }
    }).catch(() => {
        showAuthScreen();
        showAuthError('Could not reach the server.');
    });
}

function showLoadError(err) {
    const box = document.createElement('p');
    box.style.cssText = 'padding:24px;font:16px Roboto,sans-serif;color:#B3261E;';
    box.textContent = 'Tire Clicker could not start: ' + err.message +
        '. Open it through a web server (for example php -S localhost:8000), not by double-clicking the file.';
    document.body.appendChild(box);
}

async function start() {
    try {
        await loadPartials();
    } catch (err) {
        showLoadError(err);
        return;
    }

    collectElements();
    initThemeToggles();
    initMusic();
    initAuthScreen(enterGame);
    initShopTabs();
    initTireButton();
    initLogout(() => {
        resetAuthForms();
        checkSession();
    });
    initSaveOnExit();
    checkSession();
}

start();
