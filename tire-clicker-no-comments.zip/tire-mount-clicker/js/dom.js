export const el = {};

const byId = (id) => document.getElementById(id);

export function collectElements() {
    Object.assign(el, {

        screenAuth: byId('screen-auth'),
        screenGame: byId('screen-game'),
        authTabs: document.querySelectorAll('[data-auth-tab]'),
        loginForm: byId('login-form'),
        registerForm: byId('register-form'),
        authError: byId('auth-error'),

        tiresStat: byId('stat-tires'),
        rateStat: byId('stat-rate'),
        multStat: byId('stat-mult'),
        saveIndicator: byId('save-indicator'),
        topbarUsername: byId('topbar-username'),
        logoutButton: byId('logout-button'),

        carStage: byId('car-stage'),
        carFaces: document.querySelectorAll('.car-face'),
        tireButton: byId('tire-button'),
        tireFaces: document.querySelectorAll('.tire-face'),
        tireButtonLabel: byId('tire-button-label'),

        shopTabs: document.querySelectorAll('[data-shop-tab]'),
        shopGenerators: byId('shop-generators'),
        shopUpgrades: byId('shop-upgrades'),
        shopMultipliers: byId('shop-multipliers')
    });
}
