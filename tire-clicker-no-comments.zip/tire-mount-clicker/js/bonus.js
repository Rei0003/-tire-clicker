import { BONUS } from './config.js';
import { playBonus } from './sfx.js';

let active = false;
let activeUntil = 0;
let tire = null;
let timer = null;
let countdown = null;
let spawnTimer = null;
let expireTimers = [];

const TIRE_SVG = `
<svg class="nitro-tire-art" viewBox="0 0 100 100" aria-hidden="true" focusable="false">
    <circle cx="50" cy="50" r="47" fill="#17181B" stroke="#000" stroke-width="2"/>
    <g stroke="#3A3B40" stroke-width="3" stroke-linecap="round">
        ${Array.from({ length: 16 }, (_, i) => `<line x1="50" y1="5" x2="50" y2="12" transform="rotate(${i * 22.5} 50 50)"/>`).join('')}
    </g>
    <circle cx="50" cy="50" r="33" fill="#F5C024" stroke="#8A6400" stroke-width="2.5"/>
    <circle cx="50" cy="50" r="26" fill="#FFD95A" stroke="#C99A10" stroke-width="1.5"/>
    <g fill="#E0A800">
        ${Array.from({ length: 5 }, (_, i) => `<circle cx="50" cy="31" r="3" transform="rotate(${i * 72} 50 50)"/>`).join('')}
    </g>
    <path d="M55 30 L40 53 L50 53 L45 71 L62 45 L52 45 Z" fill="#FFFFFF" stroke="#8A6400" stroke-width="2" stroke-linejoin="round"/>
</svg>`;

export function getBonusMultiplier() {
    return active ? BONUS.multiplier : 1;
}

export function isBonusActive() {
    return active;
}

function host() {
    return document.querySelector('.bay-frame') || document.body;
}

function removeTire() {
    expireTimers.forEach(clearTimeout);
    expireTimers = [];
    if (tire) { tire.remove(); tire = null; }
}

function expireTire() {
    if (!tire) return;
    const leaving = tire;
    tire = null;
    leaving.classList.add('is-gone');
    leaving.disabled = true;
    setTimeout(() => leaving.remove(), 500);
    scheduleNext();
}

function removeTimer() {
    clearInterval(countdown);
    countdown = null;
    if (timer) { timer.remove(); timer = null; }
}

const BOTTLE_SVG = `
<svg class="nitro-bottle" viewBox="0 0 170 46" aria-hidden="true" focusable="false">
    <rect x="3" y="5" width="132" height="36" rx="16" fill="#E9EEF3" stroke="#1B1D22" stroke-width="3"/>
    <rect class="nitro-bottle-fill" x="7" y="9" width="124" height="28" rx="12" fill="#2B8FE0"/>
    <rect x="16" y="13" width="92" height="5" rx="2.5" fill="#FFFFFF" opacity="0.55"/>
    <text x="69" y="31" text-anchor="middle" font-family="Roboto, Arial, sans-serif" font-weight="900"
          font-style="italic" font-size="17" fill="#FFFFFF" stroke="#1B1D22" stroke-width="3" paint-order="stroke">NITRO</text>
    <rect x="135" y="14" width="12" height="18" fill="#9AA3AE" stroke="#1B1D22" stroke-width="3"/>
    <rect x="147" y="8" width="18" height="30" rx="4" fill="#F5C024" stroke="#1B1D22" stroke-width="3"/>
    <line x1="152" y1="14" x2="152" y2="32" stroke="#C99A10" stroke-width="2.5"/>
    <line x1="159" y1="14" x2="159" y2="32" stroke="#C99A10" stroke-width="2.5"/>
</svg>`;

function updateTimer() {
    const left = Math.max(0, activeUntil - Date.now());
    timer.querySelector('.nitro-timer-secs').textContent = Math.ceil(left / 1000);
    timer.querySelector('.nitro-bottle-fill').style.transform = `scaleX(${left / BONUS.durationMs})`;
    timer.classList.toggle('is-ending', left <= 5000);
}

function showTimer() {
    timer = document.createElement('div');
    timer.className = 'nitro-timer';
    timer.setAttribute('role', 'status');
    timer.innerHTML = `
        <div class="nitro-timer-head">
            <span class="nitro-timer-title">NITRO BOOST</span>
            <span class="nitro-timer-mult">${BONUS.multiplier}\u00D7 income</span>
        </div>
        ${BOTTLE_SVG}
        <div class="nitro-timer-clock"><span class="nitro-timer-secs"></span><small>s</small></div>`;
    host().appendChild(timer);
    updateTimer();
}

function endBoost() {
    active = false;
    document.body.classList.remove('nitro-active');
    removeTimer();
    scheduleNext();
}

function activate() {
    active = true;
    activeUntil = Date.now() + BONUS.durationMs;
    playBonus();
    removeTire();
    document.body.classList.add('nitro-active');

    removeTimer();
    showTimer();
    countdown = setInterval(() => {
        if (Date.now() >= activeUntil) endBoost();
        else updateTimer();
    }, 100);
}

function spawnTire() {
    if (active || tire) return;

    tire = document.createElement('button');
    tire.type = 'button';
    tire.className = 'nitro-tire';
    tire.setAttribute('aria-label',
        `Nitro Boost: ${BONUS.multiplier} times income for ${BONUS.durationMs / 1000} seconds`);
    tire.innerHTML = TIRE_SVG + `<span class="nitro-tire-label">NITRO ${BONUS.multiplier}\u00D7</span>`;

    tire.style.left = (8 + Math.random() * 70) + '%';
    tire.style.top = (6 + Math.random() * 30) + '%';

    tire.addEventListener('click', activate);
    host().appendChild(tire);

    expireTimers = [
        setTimeout(() => tire && tire.classList.add('is-expiring'), Math.max(0, BONUS.visibleMs - 3000)),
        setTimeout(expireTire, BONUS.visibleMs)
    ];
}

function randomWait() {
    const roll = 1 - Math.random();
    return BONUS.minGapMs - Math.log(roll) * BONUS.averageWaitMs;
}

function scheduleNext() {
    clearTimeout(spawnTimer);
    spawnTimer = setTimeout(trySpawn, randomWait());
}

function trySpawn() {
    if (document.hidden) {
        scheduleNext();
        return;
    }
    spawnTire();
}

export function initBonus() {
    scheduleNext();
}

export function stopBonus() {
    clearTimeout(spawnTimer);
    removeTire();
    removeTimer();
    active = false;
    document.body.classList.remove('nitro-active');
}
