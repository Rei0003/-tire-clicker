export function formatNumber(n) {
    n = Math.floor(n);
    if (n < 1000) return String(n);
    const units = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi'];
    const order = Math.min(Math.floor(Math.log10(n) / 3), units.length - 1);
    const scaled = n / Math.pow(1000, order);
    return scaled.toFixed(scaled < 10 ? 2 : 1) + units[order];
}

export function formatRate(n) {
    if (n >= 100) return formatNumber(n);
    const rounded = Math.round(n * 10) / 10;
    return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
}
